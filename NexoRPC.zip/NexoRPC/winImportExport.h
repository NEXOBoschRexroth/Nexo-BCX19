#ifndef WINIMPORTEXPORT_H_DEFINED
#define WINIMPORTEXPORT_H_DEFINED

#ifdef WIN32
  #ifdef COMPONENTS_EXPORTS
    /* only the components.dll C/C++ project should define COMPONENTS_EXPORTS
       all members within this DLL which are marked with COMPONENTS_API will be exported */
    #define COMPONENTS_API __declspec(dllexport)
  #else
    #ifndef QT_CORE_LIB
      #define COMPONENTS_API __declspec(dllimport)
    #else
      #define COMPONENTS_API
    #endif
  #endif
#else
  #define COMPONENTS_API
#endif

#endif /* WINIMPORTEXPORT_H_DEFINED */
