#ifndef STDCSTRING_H_DEFINED
#define STDCSTRING_H_DEFINED

#include <string>
#include "winImportExport.h"

#ifndef WIN32
COMPONENTS_API int strcpy_s(char* dest, unsigned int destSize, const char* src);
COMPONENTS_API int strcat_s(char* dest, unsigned int destSize, const char* src);
#endif //WIN32

/*! replaces all non alpha-numerical characters with an underscore '_'
  and returns this manipulated string */
COMPONENTS_API std::string to_nativeName(const char* name);

//leider kann man mit std::string keinen beschreibbaren Pointer bekommen,
//so dass man z.B. recv( fd, &recvBuf[recvLen], len, 0 ) aufrufen könnte
class COMPONENTS_API stdCString
{
public:
  unsigned int sBufSize; //max. number of bytes in sBuf
  char* sBuf; //pointer to a buffer
  unsigned int sLen; //number of used bytes sBuf (=strlen(sBuf))

  stdCString();
  stdCString(unsigned int memSize);
  virtual ~stdCString();
  int sRealloc( unsigned int size );
  void sClear();
  const char* sCStr(unsigned int idx=0);
  char* sStr(unsigned int idx=0);
  char& sAt( unsigned int idx);
  int sSetAt( unsigned int idx, char newValue );
  int sAssign(const char* srcStr);
  int sAppend(const char* srcStr);
  stdCString& operator=(const char* srcStr);
  stdCString& operator+=(const char* srcStr);
  char& operator[](unsigned int idx);
  char* sFind( const char* searchString, unsigned int startIdx=0 );
#ifdef WIN32
#ifndef QT_CORE_LIB
  /*! set the content of this stdCString object
      to the UTF-8 version of newString and
      returns sBuf */
  char* sSet( const WCHAR* newString );
#endif
#endif
  /*! set the content of this stdCString object
      to newString with a given length of characters and
      returns sBuf */
  char* sSet( const char* newString, unsigned int length );
};

#endif /* STDCSTRING_H_DEFINED */
