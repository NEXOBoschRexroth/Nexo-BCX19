#include <stdlib.h>
#include <string.h>
#include "stdCString.h"

#ifndef WIN32
#define strncpy_s(d,n,s,c) strncpy(d,s,c)

COMPONENTS_API int strcpy_s(char* dest, unsigned int destSize, const char* src)
{
  if (dest == 0)
  {
    return -1;
  }
  if (destSize < 1)
  {
    return -2;
  }
  if (src == 0)
  {
    return -3;
  }
  strncpy( dest, src, destSize);
  dest[destSize-1] = 0;
  return 0;
}

COMPONENTS_API int strcat_s(char* dest, unsigned int destSize, const char* src)
{
  if (dest == 0)
  {
    return -1;
  }
  if (destSize < 1)
  {
    return -2;
  }
  if (src == 0)
  {
    return -3;
  }
  unsigned int destLen = strlen( dest );
  unsigned int srcLen = strlen( src );
  if (destLen + srcLen >= destSize)
  {
    return -4;
  }
  strcat( dest, src );
  return 0;
}
#endif //WIN32

COMPONENTS_API std::string to_nativeName(const char* name)
{
  //dtprint("to_nativeName(name=%s)\n", name );
  std::string nN;
  if (name == 0)
  {
    return nN;
  }
  const char* pN = name;
  while (*pN != 0)
  {
    if (*pN < '0')
    {
      nN += '_';
    }
    else if (*pN <= '9')
    {
      nN += *pN;
    }
    else if (*pN < 'A')
    {
      nN += '_';
    }
    else if (*pN <= 'Z')
    {
      nN += *pN;
    }
    else if (*pN < 'a')
    {
      nN += '_';
    }
    else if (*pN <= 'z')
    {
      nN += *pN;
    }
    else
    {
      nN += '_';
    }
    ++pN;
  }
  return nN;
}

static char errorCharacter = 0;

stdCString::stdCString() :
  sBufSize(0),
  sBuf(0),
  sLen(0)
{
}

stdCString::stdCString(unsigned int memSize) :
  sBufSize(0),
  sBuf(0),
  sLen(0)
{
  sRealloc( memSize );
}

stdCString::~stdCString()
{
  if (sBuf != 0)
  {
    free( sBuf );
    sBuf = 0;
    sLen = 0;
  }
}

int stdCString::sRealloc( unsigned int size )
{
  if (sBufSize > size)
  { //nothing to do //recvBufSize must +1 because of string 0 termination
    return 0;
  }
  char* newBuf = (char*)realloc( sBuf, size+1 );
  if (newBuf == 0)
  {
    printf("stdCString::sRealloc(): not enough memory to allocate %d bytes for recvBuf\n", size+1);
    return -1;
  }
  //init expanded part with '\0'
  memset( &newBuf[sBufSize], 0, size+1-sBufSize);
  sBuf = newBuf;
  sBufSize = size+1;
  return 0;
}

void stdCString::sClear()
{
  sLen = 0;
  if (sBuf == 0)
  {
    sBufSize = 0;
    return;
  }
  if (sBufSize <= 0)
  {
    free( sBuf );
    sBuf = 0;
    sBufSize = 0;
    return;
  }
  memset( sBuf, 0, sBufSize );
}

const char* stdCString::sCStr(unsigned int idx/*=0*/)
{
  return sStr( idx );
}

char* stdCString::sStr(unsigned int idx/*=0*/)
{
  if ((sBuf == 0) || (sBufSize <= idx))
  {
    int ret = sRealloc( idx+1 );
    if (ret != 0)
    {
      return 0;
    }
  }
  return &sBuf[idx];
}

char& stdCString::sAt(unsigned int idx)
{
  if (idx >= sBufSize)
  {
    return errorCharacter;
  }
  if (sBuf == 0)
  {
    return errorCharacter;
  }
  return sBuf[idx];
}

int stdCString::sSetAt(unsigned int idx, char newValue)
{
  char* ptr = sStr(idx);
  if (ptr == 0)
  {
    return -1;
  }
  *ptr = newValue;
  return 0;
}

int stdCString::sAssign(const char* srcStr)
{
  if (srcStr == 0)
  {
    sClear();
    return 0;
  }
  size_t len = strlen( srcStr );
  int ret = sRealloc( len );
  if (ret != 0)
  {
    printf("stdCString::sAssign(): sRealloc(%d) returned %d\n", len, ret);
    return -1;
  }
  strcpy_s(sBuf, sBufSize, srcStr);
  sLen = len;
  return 0;
}

int stdCString::sAppend(const char* srcStr)
{
  if (srcStr == 0)
  {
    sClear();
    return 0;
  }
  size_t len = strlen( srcStr );
  int ret = sRealloc( sLen + len );
  if (ret != 0)
  {
    printf("stdCString::sAppend(): sRealloc(%d) returned %d\n", sLen+len, ret);
    return -1;
  }
  strcat_s(sBuf, sBufSize, srcStr);
  sLen += len;
  return 0;
}

stdCString& stdCString::operator = (const char* srcStr)
{
  int ret = sAssign( srcStr );
  if (ret != 0)
  {
    printf("stdCString::operator = : sAssign returned %d\n", ret);
  }
  return *this;
}

stdCString& stdCString::operator += (const char* srcStr)
{
  int ret = sAppend( srcStr );
  if (ret != 0)
  {
    printf("stdCString::operator = : sAppend returned %d\n", ret);
  }
  return *this;
}

char& stdCString::operator [] (unsigned int idx)
{
  return sAt( idx );
}

char* stdCString::sFind( const char* searchString, unsigned int startIdx/*=0*/ )
{
  if (searchString == 0)
  {
    return 0;
  }
  if (startIdx >= sBufSize)
  {
    return 0;
  }
  if (sBuf == 0)
  {
    return 0;
  }
  return strstr( sBuf, searchString );
}
#ifdef WIN32
#ifndef QT_CORE_LIB
char* stdCString::sSet( const WCHAR* newString )
{
  if (newString == 0)
  {
    return 0;
  }
  unsigned int wlen = wcslen( newString );
  if (wlen < 1)
  {
    sClear();
    return sBuf;
  }
  sRealloc( 5*wlen+1 ); //for each wide char reserve 5 bytes
  WideCharToMultiByte( CP_UTF8, 0, newString, -1, sBuf, sBufSize, NULL, NULL );
  sLen = strlen( sBuf );
  return sBuf;
}
#endif
#endif
char* stdCString::sSet( const char* newString, unsigned int length )
{
  if (newString == 0)
  {
    return 0;
  }
  if (length == 0)
  {
    sClear();
    return sBuf;
  }
  if (length > 0x7FFFFFFF)
  {
    length = strlen( newString );
  }
  if (length < 1)
  {
    sClear();
    return sBuf;
  }
  sRealloc( length+1 );
  strncpy_s( sBuf, sBufSize, newString, length );
  sBuf[length] = 0;
  sLen = length;
  return sBuf;
}
