#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "rtrAPI.h"

const int MainWindow::maxRdDataSize = 1024*1024;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow),
    rpcSock(0),
    rdData(new char[maxRdDataSize])
{
  ui->setupUi(this);
  connect( ui->pushButtonConnect, SIGNAL(clicked(bool)), this, SLOT(pbConnectPressed()) );
  connect( ui->pushButtonDisconnect, SIGNAL(clicked(bool)), this, SLOT(pbDisconnectPressed()) );
  connect( ui->pushButtonSend, SIGNAL(clicked(bool)), this, SLOT(pbSendPressed()) );
  connect( ui->pushButtonAvailableCycles, SIGNAL(clicked(bool)), this, SLOT(pbAvailCyclesPressed()) );
  connect( ui->pushButtonResult, SIGNAL(clicked(bool)), this, SLOT(pbResultPressed()) );
  connect( ui->pushButtonSubscribeResult, SIGNAL(clicked(bool)), this, SLOT(pbSubscribeResultsPressed()) );
  connect( ui->pushButtonUnsubscribeResult, SIGNAL(clicked(bool)), this, SLOT(pbUnsubscribeResultsPressed()) );
  connect( ui->pushButtonBoltData, SIGNAL(clicked(bool)), this, SLOT(pbBoltDataPressed()) );
  connect( ui->pushButtonGyroData, SIGNAL(clicked(bool)), this, SLOT(pbGyroDataPressed()) );
  connect( ui->pushButtonSetSpeed, SIGNAL(clicked(bool)), this, SLOT(pbSetSpeedPressed()) );
  connect( ui->pushButtonActiveProgramData, SIGNAL(clicked(bool)), this, SLOT(pbActPrgDataPressed()) );
  connect( ui->pushButtonSwitches, SIGNAL(clicked(bool)), this, SLOT(pbSwitchesPressed()) );
  connect( ui->pushButtonSubscribeButtons, SIGNAL(clicked(bool)), this, SLOT(pbSubscribeButtonsPressed()) );
  connect( ui->pushButtonUnsubscribeButtons, SIGNAL(clicked(bool)), this, SLOT(pbUnsubscribeButtonsPressed()) );
  connect( ui->pushButtonSubscribeProgram, SIGNAL(clicked(bool)), this, SLOT(pbSubscribeProgramPressed()) );
  connect( ui->pushButtonUnsubscribeProgram, SIGNAL(clicked(bool)), this, SLOT(pbUnsubscribeProgramPressed()) );
  connect( ui->pushButtonSetLED, SIGNAL(clicked(bool)), this, SLOT(pbSetLedPressed()) );
  connect( ui->pushButtonBattery, SIGNAL(clicked(bool)), this, SLOT(pbBatteryPressed()) );
  connect( ui->pushButtonMotorLtTemperature, SIGNAL(clicked(bool)), this, SLOT(pbMotorLtTemperaturePressed()) );
}

MainWindow::~MainWindow()
{
  pbDisconnectPressed();
  delete ui;
  delete rdData;
}

int MainWindow::rpcCall(const char* cmd)
{
  if (cmd == 0)
  {
    ui->textEditRpcCom->append( tr("<b>ERROR</b> MainWindow::rpcCall(): cmd is NULL\n") );
    return -1;
  }
  int len = strlen( cmd );
  if (len < 1)
  {
    ui->textEditRpcCom->append( tr("<b>ERROR</b> MainWindow::rpcCall(): len of cmd <= 0\n") );
    return -2;
  }
  int ret = rpcSock->write( cmd, len+1 );
  if (ret < 1)
  {
    ui->textEditRpcCom->append( tr("<b>ERROR</b> ") );
  }
  ui->textEditRpcCom->append( tr("MainWindow::rpcCall() rpcSock->write() returned %1\n").arg(ret) );
  ui->textEditRpcCom->append( tr(cmd) );
  ui->textEditRpcCom->append( tr("\n") );
  return 0;
}

int MainWindow::pbConnectPressed()
{
  if (rpcSock == 0)
  {
    ui->labelPortStatus->setText( tr("disconnected"));
    rpcSock = new QTcpSocket( this );
    connect(rpcSock, SIGNAL(connected()), this, SLOT(rpcSockConnected()));
    connect(rpcSock, SIGNAL(readyRead()), this, SLOT(rpcSockRead()));
    unsigned short port = (unsigned short)ui->lineEditPort->text().toInt();
    QString hostAdr = ui->comboBoxSstIpAdr->currentText();
    rpcSock->connectToHost( hostAdr, port );
  }
  return 0;
}

int MainWindow::pbDisconnectPressed()
{
  ui->labelPortStatus->setText( tr("disconnected"));
  if (rpcSock != 0)
  {
    rpcSock->disconnectFromHost();
    rpcSock->waitForDisconnected(3000);
    rpcSock->close();
    disconnect(rpcSock, 0, 0, 0);
    delete rpcSock;
    rpcSock = 0;
  }
  return 0;
}

int MainWindow::pbSendPressed()
{
  std::string txt = ui->textEditCmd->document()->toPlainText().toStdString();
  int ret = rpcCall( txt.c_str() );
  if (ret <= 0)
  {
    return -1;
  }
  return 0;
}

void MainWindow::rpcSockConnected()
{
  ui->labelPortStatus->setText( tr("connected"));
  std::string swCmd = rtcSwitchesStateCmd();
  qint64 ret = rpcSock->write(swCmd.c_str(), swCmd.length()+1);
  QString rT;
  if (ret < 1)
  {
    rT = "<b>ERROR</b> ";
  }
  rT += tr("MainWindow::rpcSockConnected(): rpcSock->write() returned %1\n").arg(ret);
  rT += tr(swCmd.c_str());
  rT += tr("\n");
  ui->textEditRpcCom->append( rT );
}

void MainWindow::rpcSockRead()
{
  if (rpcSock == 0)
  {
    return;
  }
  rdData[0] = 0;
  qint64 rdSize = rpcSock->read( rdData, maxRdDataSize - 2 );
  QString rT;
  if (rdSize < 1)
  {
    rT = tr("<b>ERROR</b> ");
  }
  rT += tr("MainWindow::rpcSockRead(): returned %1\n").arg(rdSize);
  ui->textEditRpcCom->append( rT );
  ui->textEditRpcCom->append( tr(rdData) );
  ui->textEditRpcCom->append( tr("\n") );
}

int MainWindow::pbAvailCyclesPressed()
{
  std::string cmd = rtrAvailableCyclesCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbResultPressed()
{
  std::string cmd = rtrResultCmd(0);
  ui->textEditCmd->setText( tr(cmd.c_str()) );
  return 0;
}

int MainWindow::pbSubscribeResultsPressed()
{
  std::string cmd = rtrSubscribeResultsCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbUnsubscribeResultsPressed()
{
  std::string cmd = rtrUnsubscribeResultsCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbBoltDataPressed()
{
  std::string cmd = rtcBoltDataCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbGyroDataPressed()
{
  std::string cmd = rtcGyroDataCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbSetSpeedPressed()
{
  std::string cmd = rtcSetSpeedCmd(0.0);
  ui->textEditCmd->setText( tr(cmd.c_str()) );
  return 0;
}

int MainWindow::pbSwitchesPressed()
{
  std::string cmd = rtcSwitchesStateCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbActPrgDataPressed()
{
  std::string cmd = rtpActiveProgramDataCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbSubscribeButtonsPressed()
{
  std::string cmd = rtcSubscribeButtonsCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbUnsubscribeButtonsPressed()
{
  std::string cmd = rtcUnsubscribeButtonsCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbSubscribeProgramPressed()
{
  std::string cmd = rtpSubscribeProgramCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbUnsubscribeProgramPressed()
{
  std::string cmd = rtpUnsubscribeProgramCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbSetLedPressed()
{
  std::string cmd = rtcSetLedCmd(0, 0, 0);
  ui->textEditCmd->setText( tr(cmd.c_str()) );
  return 0;
}

int MainWindow::pbBatteryPressed()
{
  std::string cmd = rtbBatteryStatusCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}

int MainWindow::pbMotorLtTemperaturePressed()
{
  std::string cmd = rtcMotorLtTemperatureCmd();
  int ret = rpcCall( cmd.c_str() );
  if (ret <= 0)
  {
      return -1;
  }
  return 0;
}
