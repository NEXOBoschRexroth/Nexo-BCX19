#include "winSockInit.h"

winSockInit::winSockInit() : winSockStatus(0)
{
#ifdef WIN32
  winSockStatus = WSAStartup(MAKEWORD(2,2), &wsaData);
#endif
}

winSockInit::~winSockInit()
{
#ifdef WIN32
  WSACleanup();
#endif
}
