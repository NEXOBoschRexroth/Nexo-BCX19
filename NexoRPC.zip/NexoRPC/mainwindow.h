#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QTcpSocket>

namespace Ui {
class MainWindow;
}

class compSocketClient;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:

    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    int rpcCall(const char* cmd);

public Q_SLOTS:
    int pbConnectPressed();
    int pbDisconnectPressed();
    int pbSendPressed();
    void rpcSockConnected();
    void rpcSockRead();
    int pbAvailCyclesPressed();
    int pbResultPressed();
    int pbSubscribeResultsPressed();
    int pbUnsubscribeResultsPressed();
    int pbBoltDataPressed();
    int pbGyroDataPressed();
    int pbSetSpeedPressed();
    int pbActPrgDataPressed();
    int pbSwitchesPressed();
    int pbSubscribeButtonsPressed();
    int pbUnsubscribeButtonsPressed();
    int pbSubscribeProgramPressed();
    int pbUnsubscribeProgramPressed();
    int pbSetLedPressed();
    int pbBatteryPressed();
    int pbMotorLtTemperaturePressed();

private:
    Ui::MainWindow *ui;
    QTcpSocket* rpcSock;
    char* rdData;
    static const int maxRdDataSize;
};

#endif // MAINWINDOW_H
