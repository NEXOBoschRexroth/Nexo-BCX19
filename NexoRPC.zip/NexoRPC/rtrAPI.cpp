#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rtrAPI.h"

std::string std_to_string(unsigned int num)
{
  std::string numStr;
  char numS[32];
  sprintf(numS, "%u", num);
  numStr = numS;
  return numStr;
}

std::string std_to_string(int num)
{
  std::string numStr;
  char numS[32];
  sprintf(numS, "%d", num);
  numStr = numS;
  return numStr;
}

std::string std_to_string(double num)
{
  std::string numStr;
  char numS[64];
  sprintf(numS, "%f", num);
  numStr = numS;
  return numStr;
}

static unsigned int rpcCmdIdCounter = 0;
#ifndef QT_CORE_LIB
static const char* strTemplateCmdId = "\"cmdID\":\"%u\"";
#endif
static const char* strTemplateCompTighteningResults = "\"comp\":\"TighteningResults\"";
static const char* strTemplateCompTighteningControl = "\"comp\":\"TighteningControl\"";
static const char* strTemplateCompToolBattery = "\"comp\":\"ToolBattery\"";

static const char* strTemplateFctAvailableCycles = "\"fct\":\"availableCycles\"";
COMPONENTS_API std::string rtrAvailableCyclesCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningResults;
  jc += ",\n";
  jc += strTemplateFctAvailableCycles;
  jc += "\n}";
  return jc;
}

COMPONENTS_API int rtrAvailableCyclesRslt(const char* jRslt, int& minCycle, int& maxCycle)
{
  compJson jStr( jRslt, true );
  int result = 0;
  minCycle = jStr.cmpUIntValue( result, "minCycle" );
  if (result != 0)
  {
    return -1;
  }
  maxCycle = jStr.cmpUIntValue( result, "maxCycle" );
  if (result != 0)
  {
    return -2;
  }
  int ret = jStr.cmpUIntValue( result, "availableResults" );
  if (result != 0)
  {
    return -3;
  }
  return ret;
}
#ifndef QT_CORE_LIB
COMPONENTS_API int rtrAvailableCycles(compSocketBase& sock, int& minCycle, int& maxCycle)
{
  if ( !sock.sbConnected )
  {
    sock.sbConnect();
  }
  if ( !sock.sbConnected )
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrAvailableCycles(): no connection to %s\n", sock.sbIpAdr.c_str());
    return -1;
  }
  std::string jCmd = rtrAvailableCyclesCmd();
  const char* cmdStr = jCmd.c_str();
  int msgLen = strlen( cmdStr );

  sock.sbSend( cmdStr, msgLen+1 );

  //wait max. 0.5 seconds for the return value
  int ret = sock.sbSelectRead( 500000 ); //0.5 seconds
  if (ret != 1)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrAvailableCycles(): no response from %s\n", sock.sbIpAdr.c_str() );
    return -2;
  }
  ret = sock.sbRecvAll();
  if (ret != 0)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrAvailableCycles(): sock.sbRecvAll(ip=%s) returned %d\n", sock.sbIpAdr.c_str(), ret);
    return -3;
  }
  ret = rtrAvailableCyclesRslt(sock.sbRecvBuf.sCStr(), minCycle, maxCycle);
  if (ret < 0)
  {
    return -4;
  }
  return ret;
}
#endif
static const char* strTemplateCycle = "\"cycle\":";
static const char* strTemplateFctResult = "\"fct\":\"result\"";
COMPONENTS_API std::string rtrResultCmd(int cycle)
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningResults;
  jc += ",\n";
  jc += strTemplateFctResult;
  jc += ",\n";
  jc += strTemplateCycle;
  jc += std_to_string( cycle );
  jc += "\n}";
  return jc;
}
#ifndef QT_CORE_LIB
COMPONENTS_API int rtrResult(compSocketBase& sock, compJson& jRslt, int cycle )
{
  if ( !sock.sbConnected )
  {
    sock.sbConnect();
  }
  if ( !sock.sbConnected )
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrResult(): no connection to %s\n", sock.sbIpAdr.c_str());
    return -1;
  }
  if ( jRslt.cmpJStringIsReference )
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrResult(): jRslt.cmpJString is only a reference - no realloc() possible\n");
    return -2;
  }
  char msg[1024];
  memset(msg, 0, sizeof(msg));
  msg[0] = '{';
  msg[1] = '\n';
  unsigned int myRpcCounter = ++rpcCmdIdCounter;
  sprintf( &msg[2], strTemplateCmdId, myRpcCounter );
  strcat_s( msg, sizeof(msg), ",\n" );
  strcat_s( msg, sizeof(msg), strTemplateCompTighteningResults );
  strcat_s( msg, sizeof(msg), ",\n" );
  strcat_s( msg, sizeof(msg), strTemplateFctResult );
  strcat_s( msg, sizeof(msg), ",\n" );
  int msgLen = strlen( msg );
  sprintf( &msg[msgLen], strTemplateCycle, cycle );
  strcat_s( msg, sizeof(msg), "\n}" );
  msgLen = strlen( msg );
  msg[msgLen] = 0;

  sock.sbSend( msg, msgLen+1 );

  //wait max. 0.5 seconds for the return value
  int ret = sock.sbSelectRead( 3000000 ); //3 seconds
  if (ret != 1)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrResult(): no response from %s\n", sock.sbIpAdr.c_str() );
    return -3;
  }
  ret = sock.sbRecvAll();
  if (ret != 0)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrResult(): sock.sbRecvAll(ip=%s) returned %d\n", sock.sbIpAdr.c_str(), ret);
    return -4;
  }
  char* js = (char*)realloc(jRslt.cmpJString, sock.sbRecvBuf.sLen+1);
  if (js == 0)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrResult(): not enough memory - need %u bytes\n", sock.sbRecvBuf.sLen+1);
    return -5;
  }
  strcpy_s( js, sock.sbRecvBuf.sLen+1, sock.sbRecvBuf.sBuf );
  jRslt.cmpJString = js;
  jRslt.cmpJStreamLength = sock.sbRecvBuf.sLen;
  return 0;
}
#endif
static const char* strTemplateFctSubscribeResults = "\"fct\":\"subscribeResults\"";
COMPONENTS_API std::string rtrSubscribeResultsCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningResults;
  jc += ",\n";
  jc += strTemplateFctSubscribeResults;
  jc += "\n}";
  return jc;
}

#ifndef QT_CORE_LIB
COMPONENTS_API int rtrSubscribeResults( compSocketBase& sock )
{
  if ( !sock.sbConnected )
  {
    sock.sbConnect();
  }
  if ( !sock.sbConnected )
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrSubscribeResults(): no connection to %s\n", sock.sbIpAdr.c_str());
    return -1;
  }
  std::string msg = rtrSubscribeResultsCmd();
  sock.sbSend( msg.c_str(), msg.length()+1 );

  //wait max. 0.5 seconds for the return value
  int ret = sock.sbSelectRead( 500000 ); //0.5 seconds
  if (ret != 1)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrSubscribeResults(): no response from %s\n", sock.sbIpAdr.c_str() );
    return -2;
  }
  ret = sock.sbRecvAll();
  if (ret != 0)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrSubscribeResults(): sock.sbRecvAll(ip=%s) returned %d\n", sock.sbIpAdr.c_str(), ret);
    return -3;
  }
  compJson jStr( sock.sbRecvBuf.sCStr(), true );
  int result = 0;
  bool rsltFlag = jStr.cmpBoolValue( result, "rslt" );
  return rsltFlag?0:-4;
}
#endif
static const char* strTemplateFctUnsubscribeResults = "\"fct\":\"unsubscribeResults\"";
COMPONENTS_API std::string rtrUnsubscribeResultsCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningResults;
  jc += ",\n";
  jc += strTemplateFctUnsubscribeResults;
  jc += "\n}";
  return jc;
}

#ifndef QT_CORE_LIB
COMPONENTS_API int rtrUnsubscribeResults( compSocketBase& sock )
{
  if ( !sock.sbConnected )
  {
    sock.sbConnect();
  }
  if ( !sock.sbConnected )
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrUnsubscribeResults(): no connection to %s\n", sock.sbIpAdr.c_str());
    return -1;
  }
  std::string msg = rtrUnsubscribeResultsCmd();
  sock.sbSend( msg.c_str(), msg.length()+1 );

  //wait max. 0.5 seconds for the return value
  int ret = sock.sbSelectRead( 500000 ); //0.5 seconds
  if (ret != 1)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrUnsubscribeResults(): no response from %s\n", sock.sbIpAdr.c_str() );
    return -2;
  }
  ret = sock.sbRecvAll();
  if (ret != 0)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtrUnsubscribeResults(): sock.sbRecvAll(ip=%s) returned %d\n", sock.sbIpAdr.c_str(), ret);
    return -3;
  }
  compJson jStr( sock.sbRecvBuf.sCStr(), true );
  int result = 0;
  bool rsltFlag = jStr.cmpBoolValue( result, "rslt" );
  return rsltFlag?0:-4;
}
#endif
static const char* strTemplateFctBoltData = "\"fct\":\"boltData\"";
COMPONENTS_API std::string rtcBoltDataCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningControl;
  jc += ",\n";
  jc += strTemplateFctBoltData;
  jc += "\n}";
  return jc;
}

#ifndef QT_CORE_LIB
COMPONENTS_API int rtcBoltData(compSocketBase& sock, R_BOLT_DATA& bd)
{
  if ( !sock.sbConnected )
  {
    sock.sbConnect();
  }
  if ( !sock.sbConnected )
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcBoltData(): no connection to %s\n", sock.sbIpAdr.c_str());
    return -1;
  }
  std::string msg = rtcBoltDataCmd();
  sock.sbSend( msg.c_str(), msg.length()+1 ); //including 0-termination

  //wait max. 0.5 seconds for the return value
  int ret = sock.sbSelectRead( 500000 ); //0.5 seconds
  if (ret != 1)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcBoltData(): no response from %s\n", sock.sbIpAdr.c_str() );
    return -2;
  }
  ret = sock.sbRecvAll();
  if (ret != 0)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcBoltData(): sock.sbRecvAll(ip=%s) returned %d\n", sock.sbIpAdr.c_str(), ret);
    return -3;
  }
  compJson jStr( sock.sbRecvBuf.sCStr(), true );
  int result = 0;
  bd.counter = jStr.cmpUIntValue( result, "counter" );
  bd.timeStamp = jStr.cmpTimeStampValue( result, "timeStamp" );
  bd.boltTorque = jStr.cmpDblValue( result, "boltTorque" );
  bd.boltAngle100 = jStr.cmpDblValue( result, "boltAngle100" );
  bd.motorCurrent = jStr.cmpDblValue(result, "motorCurrent" );
  return 0;
}
#endif
static const char* strTemplateFctGyroData = "\"fct\":\"gyroData\"";
COMPONENTS_API std::string rtcGyroDataCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningControl;
  jc += ",\n";
  jc += strTemplateFctGyroData;
  jc += "\n}";
  return jc;
}

#ifndef QT_CORE_LIB
COMPONENTS_API int rtcGyroData(compSocketBase& sock, R_GYRO_DATA& gd)
{
  if ( !sock.sbConnected )
  {
    sock.sbConnect();
  }
  if ( !sock.sbConnected )
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcGyroData(): no connection to %s\n", sock.sbIpAdr.c_str());
    return -1;
  }
  char msg[1024];
  memset(msg, 0, sizeof(msg));
  msg[0] = '{';
  msg[1] = '\n';
  unsigned int myRpcCounter = ++rpcCmdIdCounter;
  sprintf( &msg[2], strTemplateCmdId, myRpcCounter );
  strcat_s( msg, sizeof(msg), ",\n" );
  strcat_s( msg, sizeof(msg), strTemplateCompTighteningControl );
  strcat_s( msg, sizeof(msg), ",\n" );
  strcat_s( msg, sizeof(msg), strTemplateFctGyroData );
  strcat_s( msg, sizeof(msg), "\n}" );
  int msgLen = strlen( msg );
  msg[msgLen] = 0;

  sock.sbSend( msg, msgLen+1 ); //including 0-termination

  //wait max. 1 seconds for the return value
  int ret = sock.sbSelectRead( 1000000 ); //1 second
  if (ret != 1)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcGyroData(): no response from %s\n", sock.sbIpAdr.c_str() );
    return -2;
  }
  ret = sock.sbRecvAll();
  if (ret != 0)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcGyroData(): sock.sbRecvAll(ip=%s) returned %d\n", sock.sbIpAdr.c_str(), ret);
    return -3;
  }
  compJson jStr( sock.sbRecvBuf.sCStr(), true );
  int result = 0;
  gd.counter = jStr.cmpUIntValue( result, "counter" );
  gd.timeStamp = jStr.cmpTimeStampValue( result, "timeStamp" );
  gd.gyAngleDx = jStr.cmpIntValue( result, "gyAngleDx" );
  gd.gyAngleDy = jStr.cmpIntValue( result, "gyAngleDy" );
  gd.gyAngleDz = jStr.cmpIntValue( result, "gyAngleDz" );
  gd.gyAccelDx = jStr.cmpIntValue( result, "gyAccelDx" );
  gd.gyAccelDy = jStr.cmpIntValue( result, "gyAccelDy" );
  gd.gyAccelDz = jStr.cmpIntValue( result, "gyAccelDz" );
  return 0;
}
#endif

static const char* strTemplateFctSetSpeed = "\"fct\":\"setSpeed\"";
COMPONENTS_API std::string rtcSetSpeedCmd(double rpmSpeed)
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningControl;
  jc += ",\n";
  jc += strTemplateFctSetSpeed;
  jc += ",\n";
  jc += "\"rpmSpeed\":";
  jc += std_to_string( rpmSpeed );
  jc += "\n}";
  return jc;
}

#ifndef QT_CORE_LIB
COMPONENTS_API int rtcSetSpeed(compSocketBase& sock, double rpmSpeed)
{
  if ( !sock.sbConnected )
  {
    sock.sbConnect();
  }
  if ( !sock.sbConnected )
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcSetSpeed(): no connection to %s\n", sock.sbIpAdr.c_str());
    return -1;
  }
  char msg[1024];
  memset(msg, 0, sizeof(msg));
  msg[0] = '{';
  msg[1] = '\n';
  unsigned int myRpcCounter = ++rpcCmdIdCounter;
  sprintf( &msg[2], strTemplateCmdId, myRpcCounter );
  strcat_s( msg, sizeof(msg), ",\n" );
  strcat_s( msg, sizeof(msg), strTemplateCompTighteningControl );
  strcat_s( msg, sizeof(msg), ",\n" );
  strcat_s( msg, sizeof(msg), strTemplateFctSetSpeed );
  strcat_s( msg, sizeof(msg), ",\n\"rpmSpeed\":");
  char buf[32];
  sprintf( buf, "%f", rpmSpeed);
  strcat_s( msg, sizeof(msg), buf );
  strcat_s( msg, sizeof(msg), "\n}" );
  int msgLen = strlen( msg );
  msg[msgLen] = 0;

  sock.sbSend( msg, msgLen+1 ); //including 0-termination

  //wait max. 1 seconds for the return value
  int ret = sock.sbSelectRead( 1000000 ); //1 second
  if (ret != 1)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcSetSpeed(): no response from %s\n", sock.sbIpAdr.c_str() );
    return -2;
  }
  ret = sock.sbRecvAll();
  if (ret != 0)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcSetSpeed(): sock.sbRecvAll(ip=%s) returned %d\n", sock.sbIpAdr.c_str(), ret);
    return -3;
  }
  compJson jStr( sock.sbRecvBuf.sCStr(), true );
  int result = 0;
  ret = jStr.cmpIntValue( result, "returned" );
  return ret;
}
#endif
static const char* strTemplateSwitchesState = "\"fct\":\"switchesState\"";
COMPONENTS_API std::string rtcSwitchesStateCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningControl;
  jc += ",\n";
  jc += strTemplateSwitchesState;
  jc += "\n}";
  return jc;
}

#ifndef QT_CORE_LIB
COMPONENTS_API int rtcSwitchesState(compSocketBase& sock, R_SWITCHES_STATE& sw)
{
  if ( !sock.sbConnected )
  {
    sock.sbConnect();
  }
  if ( !sock.sbConnected )
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcSwitchesState(): no connection to %s\n", sock.sbIpAdr.c_str());
    return -1;
  }
  const char* msg = rtcSwitchesStateCmd().c_str();
  int msgLen = strlen( msg );
  sock.sbSend( msg, msgLen+1 ); //including 0-termination
  //wait max. 1 seconds for the return value
  int ret = sock.sbSelectRead( 1000000 ); //1 second
  if (ret != 1)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcSwitchesState(): no response from %s\n", sock.sbIpAdr.c_str() );
    return -2;
  }
  ret = sock.sbRecvAll();
  if (ret != 0)
  {
    //lm.slPrint(LOG_ERR, "rtrAPI.cpp rtcSwitchesState(): sock.sbRecvAll(ip=%s) returned %d\n", sock.sbIpAdr.c_str(), ret);
    return -3;
  }
  compJson jStr( sock.sbRecvBuf.sCStr(), true );
  int result = 0;
  sw.counter = jStr.cmpUIntValue( result, "counter" );
  sw.timeStamp = jStr.cmpTimeStampValue( result, "timeStamp" );
  sw.lrSwitch = jStr.cmpIntValue( result, "lrSwitch" );
  sw.startBtn = jStr.cmpUIntValue( result, "startBtn" );
  return 0;
}
#endif

static const char* strTemplateFctSubscribeButtons = "\"fct\":\"subscribeButtons\"";
COMPONENTS_API std::string rtcSubscribeButtonsCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningControl;
  jc += ",\n";
  jc += strTemplateFctSubscribeButtons;
  jc += "\n}";
  return jc;
}

static const char* strTemplateFctUnsubscribeButtons = "\"fct\":\"unsubscribeButtons\"";
COMPONENTS_API std::string rtcUnsubscribeButtonsCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningControl;
  jc += ",\n";
  jc += strTemplateFctUnsubscribeButtons;
  jc += "\n}";
  return jc;
}

static const char* strTemplateActiveProgramData = "\"fct\":\"tpRunningState\"";
COMPONENTS_API std::string rtpActiveProgramDataCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningControl;
  jc += ",\n";
  jc += strTemplateActiveProgramData;
  jc += "\n}";
  return jc;
}

static const char* strTemplateFctSubscribeProgram = "\"fct\":\"subscribeProgram\"";
COMPONENTS_API std::string rtpSubscribeProgramCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningControl;
  jc += ",\n";
  jc += strTemplateFctSubscribeProgram;
  jc += "\n}";
  return jc;
}

static const char* strTemplateFctUnsubscribeProgram = "\"fct\":\"unsubscribeProgram\"";
COMPONENTS_API std::string rtpUnsubscribeProgramCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningControl;
  jc += ",\n";
  jc += strTemplateFctUnsubscribeProgram;
  jc += "\n}";
  return jc;
}

static const char* strTemplateFctSetLED = "\"fct\":\"setLED\"";
COMPONENTS_API std::string rtcSetLedCmd(char cRed, char cGreen, char cBlue)
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningControl;
  jc += ",\n";
  jc += strTemplateFctSetLED;
  jc += ",\n";
  jc += "\"ledRed\":";
  jc += std_to_string( cRed );
  jc += ",\n";
  jc += "\"ledGreen\":";
  jc += std_to_string( cGreen );
  jc += ",\n";
  jc += "\"ledBlue\":";
  jc += std_to_string( cBlue );
  jc += "\n}";
  return jc;
}

static const char* strTemplateFctBatteryStatus = "\"fct\":\"batteryStatus\"";
COMPONENTS_API std::string rtbBatteryStatusCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompToolBattery;
  jc += ",\n";
  jc += strTemplateFctBatteryStatus;
  jc += "\n}";
  return jc;
}

static const char* strTemplateFctMotorLtTemperature = "\"fct\":\"motorLtTemperature\"";
COMPONENTS_API std::string rtcMotorLtTemperatureCmd()
{
  std::string jc = "{\n\"cmdID\":\"";
  ++rpcCmdIdCounter;
  jc += std_to_string( rpcCmdIdCounter );
  jc += "\",\n";
  jc += strTemplateCompTighteningControl;
  jc += ",\n";
  jc += strTemplateFctMotorLtTemperature;
  jc += "\n}";
  return jc;
}
