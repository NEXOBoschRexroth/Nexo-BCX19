#ifndef COMPJSON_H__DEFINED
#define COMPJSON_H__DEFINED

#include <string>
#ifdef linux
#include "syscJSON.h"
#else
#include "cJSON.h"
#endif /* linux */
#ifndef COMPONENTS_API
#define COMPONENTS_API
#endif

/*! this class encapsulates the JSON C-functions for use with RPC and/or IPC */
class COMPONENTS_API compJson
{
public:
  /*! points to the root item after compParse() was called. */
  cJSON* cmpJRoot; //!< cJSON_Delete() will be called with the destructor

  /*! Controls the ownership of cmpJRoot */
  bool cmpJRootIsReference; /*!< false = cmpJson is the owner of cmpJRoot and will delete it with the destructor.
                                 true  = cmpJRoot is only a reference and will not be deleted */

  /*! points to the zero terminated JSON string after compPrint() was called */
  char* cmpJString; //!< free() will be called with the destructor

  /*! length of json-Stream in cmpJString from first '{' to last '}' (including the braces) */
  unsigned int cmpJStreamLength;

  /*! Controls the ownership of cmpJString */
  bool cmpJStringIsReference; /*!< false = cmpJson is the owner of cmpJString and will delete it with the destructor.
                                   true  = cmpJString is only a reference and will not be deleted */

  /*! default constructor - does nothing */
  compJson();

  /*! constructor - set cmpJRoot.
    If isRef is false compJson takes ownership of this pointer and will delete it latest with the destructor.
    If isRef is true compJson handles jRoot only as reference (never delete it).
    Makes a deep copy of jRoot if createCopy is true. compJson gets owner of the copy but not of jRoot. */
  compJson( const cJSON* jRoot, bool isRef=false, bool createCopy=false );

  /*! constructor - parses jString.
    If isRef is false compJson takes ownership of jString and will delete it latest with the destructor.
    If isRef is true compJson handles jString only as reference (never delete it).
    Makes a copy of the string if createCopy is true. In this case compJson gets owner of the copy but not of jString. */
  compJson( const char* jString, bool isRef=false, bool createCopy=false );

  /*! calls clear() */
  virtual ~compJson();

  /*! calls free(cmpJStream) and cmpDelete(cmpJRoot) if pointers are valid and ...IsReference is false */
  int cmpClear();

  /*! searches for the item with name itemName and returns its content */
  std::string cmpStringValue(int& result, const char* itemName );

  /*! searches for the item with name itemName and returns its content */
  bool cmpBoolValue(int& result, const char* itemName );

  /*! searches for the item with name itemName and returns its content */
  unsigned int cmpUIntValue(int& result, const char* itemName );

  /*! searches for the item with name itemName and returns its content */
  int cmpIntValue(int& result, const char* itemName );

  /*! searches for the item with name itemName and returns its content */
  double cmpDblValue(int& result, const char* itemName );

  /*! searches for the item with name itemName and set its content to itemValue.
      If the item does not exist it will be created.
      If the item exists the value of the item will be changed */
  int cmpSetDblValue( const char* itemName, double itemValue );

  /*! searches for the item with name itemName and returns its content in timeStamp
      member itemNames must be 'tv_sec' and 'tv_nsec' */
  struct timespec cmpTimeStampValue(int& result, const char* itemName );

  /*! searches for the item with name itemName and set its content to itemValue.
      If the item does not exist it will be created. */
  int cmpSetTimeStampValue( const char* itemName, const struct timespec& itemValue );

  /*! searches for the item with name itemName and set its content to itemValue.
      If the item does not exist it will be created if itemValue != NULL.
      If the item exists but itemValue == NULL the item will be removed. */
  int cmpSetStringValue( const char* itemName, const char* itemValue );

  /*! searches for the item with name itemName and set its content to itemValue.
      If the item does not exist it will be created.
      If the item exists the value of the item will be changed */
  int cmpSetUIntValue( const char* itemName, unsigned int itemValue );

  /*! searches for the item with name itemName and set its content to itemValue.
      If the item does not exist it will be created.
      If the item exists the value of the item will be changed */
  int cmpSetIntValue( const char* itemName, int itemValue );

  /*! searches for the item with name itemName and set its content to itemValue.
      If the item does not exist it will be created.
      If the item exists the value of the item will be changed */
  int cmpSetBoolValue( const char* itemName, bool itemValue );

  /*! searches for the item with name itemName and set its content to itemValue.
      If the item does not exist it will be created if itemValue != NULL.
      If the item exists but itemValue == NULL the item will be removed. */
  int cmpSetObject( const char* itemName, compJson* itemValue );

  /*! searches for the item with name itemName and returns its item-content */
  cJSON* cmpItem( const char* itemName );

  /*! serializes cmpJRoot into a string */
  std::string cmpPrint();

  /*! parses the content of the member cmpJString.
      The result is in member cmpJRoot.
      If cmpJRoot is not NULL, cmpJRoot will be deleted */
  int cmpParse();

  /*! parse the jsonString. The result is in member cmpJRoot.
      First of all clear() will be called
      The content of jsonString will NOT be copied into cmpJString */
  int cmpParse(const std::string& jsonString);
};

#endif // COMPJSON_H__DEFINED
