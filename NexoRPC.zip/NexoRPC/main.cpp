#include "mainwindow.h"
#include <QApplication>
#include "winSockInit.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
  winSockInit wsa;
    return a.exec();
}
