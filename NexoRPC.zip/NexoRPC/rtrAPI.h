#ifndef RTRAPI_H_DEFINED
#define RTRAPI_H_DEFINED
/* remote tightening results API */

#ifndef _TIMESPEC_DEFINED
#ifdef WIN32
#ifndef QT_CORE_LIB
struct timespec
{
  time_t tv_sec; /* Seconds. */
  long int tv_nsec;	/* Nanoseconds. */
};
#define _TIMESPEC_DEFINED
#endif
#endif
#endif
#ifndef QT_CORE_LIB
#include "compSocketBase.h"
#endif
#include "compJson.h"

/* ////////////////////////////////////////////////////////////////////////////
tightening result functions are starting with rtr...
//////////////////////////////////////////////////////////////////////////// */

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtrAvailableCyclesCmd();

/*! returns the number of available results,
    in minCycle the oldest result,
    in maxCycle the youngest result. */
COMPONENTS_API int rtrAvailableCyclesRslt(
  const char* jRslt, /*!< [in] the json-stream received from the tightening system */
  int& minCycle, /*!< [out] the cycle number of the oldest result */
  int& maxCycle /*!< [out] the cycle number of the youngest result */
  );
#ifndef QT_CORE_LIB
/*! returns the number of available results in the tightening controller
    and in minCycle the min. available cycle number
        in maxCycle the max. available cycle number
    returns -1 if the connection to the tightening system could not established
    returns -2 if the request was sent but the tightening system does not response within the timeout of 500ms
*/
COMPONENTS_API int rtrAvailableCycles(
  compSocketBase& sock, /*!< socket connection to the tightening system */
  int& minCycle, /*!< [out] the tightening result with the lowest cycle number */
  int& maxCycle /*!< [out] the tightening result with the highest cycle number */
  );
#endif

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtrResultCmd(
  int cycle /*!< the cycle number of the result to be received */
  );

#ifndef QT_CORE_LIB
/*! returns 0 if the requested result with the cycle number exists
    and in jRslt the result of the request.
    returns -1 if the connection to the tightening system could not established
    returns -2 if the request was sent but the tightening system does not response within the timeout of 500ms
*/
COMPONENTS_API int rtrResult(
  compSocketBase& sock, /*!< socket connection to the tightening system */
  compJson& jRslt, /*!< in jRslt.cmpJString the complete response - json parser will not be called */
  int cycle /*!< the cycle number of the tightening result which will be returned */
  );
#endif

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtrSubscribeResultsCmd();

#ifndef QT_CORE_LIB
/*! returns 0 if the subscription was successful
*/
COMPONENTS_API int rtrSubscribeResults(
  compSocketBase& sock /*!< socket connection to the tightening system */
  );
#endif

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtrUnsubscribeResultsCmd();

#ifndef QT_CORE_LIB
/*! returns 0 if the unsubscription was successful
*/
COMPONENTS_API int rtrUnsubscribeResults(
  compSocketBase& sock /*!< socket connection to the tightening system */
  );
#endif
/* ////////////////////////////////////////////////////////////////////////////
tightening controller functions are starting with rtc...
//////////////////////////////////////////////////////////////////////////// */

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtcBoltDataCmd();

typedef struct rBoltData_struct
{
  unsigned int counter; /*!< before and after data will be written into the shared memory
    this counter will be incremented by 1
    this means if the counter is an odd number, following values are inconsistent
    if the counter is an even number, the values fit together */
  struct timespec timeStamp; /*!< .tv_sec seconds since Nexo start
                                  .tv_nsec nanoseconds */
  double boltTorque; /*! [Nm] negative values indicates direction changed */
  double boltAngle100; /*!< [degree] ring value in range of about -15000..+15000 (depends on gear ratios) */
  double motorCurrent; /*!< [Ampere] */
}R_BOLT_DATA;

#ifndef QT_CORE_LIB
/*! Returns in bd the current torque, angleDelta and time stamp
    The function returns 0 if successful */
COMPONENTS_API int rtcBoltData(
  compSocketBase& sock, /*!< socket connection to the tightening system */
  R_BOLT_DATA& bd /*!< bold data torque and angle */
  );
#endif

/*! Gyroscope */
/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtcGyroDataCmd();

typedef struct rGyroData_struct
{
  unsigned int counter; /*!< before and after data will be written into the shared memory
    this counter will be incremented by 1
    this means if the counter is an odd number, following values are inconsistent
    if the counter is an even number, the values fit together */
  struct timespec timeStamp; /*!< .tv_sec seconds since Nexo start
                                  .tv_nsec nanoseconds */
  int gyAngleDx; //gyroscope x direction velocity
  int gyAngleDy; //gyroscope y direction velocity
  int gyAngleDz; //gyroscope z direction velocity
  int gyAccelDx; //acceleration sensor x direction
  int gyAccelDy; //acceleration sensor y direction
  int gyAccelDz; //acceleration sensor z direction
}R_GYRO_DATA;

#ifndef QT_CORE_LIB
/*! Returns in gd the current gyro data
    The function returns 0 if successful */
COMPONENTS_API int rtcGyroData(
  compSocketBase& sock, /*!< socket connection to the tightening system */
  R_GYRO_DATA& gd /*!< gyro data: acceleration and angle velocity */
  );
#endif

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtcSetSpeedCmd(double rpmSpeed);

#ifndef QT_CORE_LIB
/*! Set the new rpm speed
    The function returns 0 if successful */
COMPONENTS_API int rtcSetSpeed(
  compSocketBase& sock, /*!< socket connection to the tightening system */
  double rpmSpeed /*!< [rpm] new velocity */
  );
#endif

/*! switches */

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtcSwitchesStateCmd();

typedef struct rSwitchesState_struct
{
  unsigned int counter; /*!< before and after data will be written into the shared memory
    this counter will be incremented by 1
    this means if the counter is an odd number, following values are inconsistent
    if the counter is an even number, the values fit together */
  struct timespec timeStamp; /*!< .tv_sec seconds since Nexo start
                                  .tv_nsec nanoseconds */
  int lrSwitch; //!< -1=left, 0=off, +1=right
  unsigned int startBtn; //!< 0..100% pressed
}R_SWITCHES_STATE;

#ifndef QT_CORE_LIB
/*! Returns in sw the current status of the switches
    The function returns 0 if successful */
COMPONENTS_API int rtcSwitchesState(
  compSocketBase& sock, /*!< socket connection to the tightening system */
  R_SWITCHES_STATE& sw /*!< status of the left-right-switch and start button */
  );
#endif

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtcSubscribeButtonsCmd();

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtcUnsubscribeButtonsCmd();

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtcSetLedCmd(char cRed, char cGreen, char cBlue);

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtcMotorLtTemperatureCmd();

/* ////////////////////////////////////////////////////////////////////////////
tightening program functions are starting with rtp...
//////////////////////////////////////////////////////////////////////////// */

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtpActiveProgramDataCmd();

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtpSubscribeProgramCmd();

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtpUnsubscribeProgramCmd();

/* ////////////////////////////////////////////////////////////////////////////
battery functions are starting with rtp...
//////////////////////////////////////////////////////////////////////////// */

/*! returns the command string which can be send to the tightening system */
COMPONENTS_API std::string rtbBatteryStatusCmd();

#endif /* RTRAPI_H_DEFINED */
