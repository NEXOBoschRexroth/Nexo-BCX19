#ifndef WINSOCKINIT_H_DEFINED
#define WINSOCKINIT_H_DEFINED

#include "winImportExport.h"
#ifdef WIN32
  #define WIN32_LEAN_AND_MEAN /* Exclude rarely-used stuff from Windows headers */
  #include <windows.h>
  #include <winsock2.h>
  #if (_WIN32_WINNT < 0x0600)
    #undef _WIN32_WINNT
    #define _WIN32_WINNT 0x0600
  #endif
  #include <ws2tcpip.h>
#endif

class COMPONENTS_API winSockInit
{
public:
  int winSockStatus;
#ifdef WIN32
  WSADATA wsaData;
#endif /*WIN32*/

  winSockInit();
  virtual ~winSockInit();
};

#endif /*WINSOCKINIT_H_DEFINED*/
