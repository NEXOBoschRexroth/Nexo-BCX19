package mids;

import static org.junit.Assert.*;

import org.junit.Test;

public class MID0001Test {

	@Test
	public void testCreateHeader() {
		//fail("Not yet implemented");
	}

}
