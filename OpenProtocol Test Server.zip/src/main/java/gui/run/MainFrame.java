package gui.run;

import gui.menu.DefaultMenuBar;
import gui.menu.IMIDMenuItemAction;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.LinkedList;
import java.util.Set;
import java.util.prefs.Preferences;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

import org.apache.log4j.Appender;
import org.apache.log4j.Layout;
import org.apache.log4j.spi.ErrorHandler;
import org.apache.log4j.spi.Filter;
import org.apache.log4j.spi.LoggingEvent;
import org.flexdock.docking.DockingConstants;
import org.flexdock.docking.DockingManager;
import org.flexdock.docking.DockingPort;
import org.flexdock.docking.props.DockingPortPropertySet;
import org.flexdock.util.SwingUtility;
import org.flexdock.view.View;
import org.flexdock.view.Viewport;

import run.OpenProtocolInit;

public class MainFrame extends JFrame implements DockingConstants {

	private Appender _logger;

	private View _mainView;

	private View _logView;

	private JPanel _mainPane;

	private DefaultMenuBar _menuBar;

	private JTextArea _logArea;

	private JPanel createContentPane() {
		JPanel p = new JPanel(new BorderLayout(0, 0));
		p.setBorder(new EmptyBorder(5, 5, 5, 5));

		Viewport viewport = new Viewport();
		p.add(viewport, BorderLayout.CENTER);
		viewport.dock(getMainView());
		getMainView().dock(getLogView(), SOUTH_REGION, _dockRel);

		return p;
	}

	private View createView(String id, String text) {
		View view = new View(id, text);
		return view;
	}

	public MainFrame() {
		initialize();
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				saveState();
			}
		});
	}

	private int _dimX, _dimY, _winState, _locX, _locY;
	float _dockRel;
	
	private void initialize() 
	{
		loadState();
		SwingUtility.setPlaf("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		DockingManager.setFloatingEnabled(true);
		setContentPane(createContentPane());
		setSize(new Dimension(_dimX, _dimY));
		setExtendedState(_winState);
		if (_locX != Integer.MAX_VALUE && _locY != Integer.MAX_VALUE) setLocation(_locX, _locY);
		setTitle("Open Protocol Gegenstelle");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setJMenuBar(getDefaultMenuBar());
	}

	private int getPref(Preferences prefs, String key, int defVal)
	{
		try {
			return Integer.parseInt(prefs.get(key, Integer.toString(defVal)));
		}
		catch (NumberFormatException e) {
			return defVal;
		}
	}
	private float getPref(Preferences prefs, String key, float defVal)
	{
		try {
			return Float.parseFloat(prefs.get(key, Float.toString(defVal)));
		}
		catch (NumberFormatException e) {
			return defVal;
		}
	}
	
	private void loadState()
	{
		Preferences prefs = Preferences.userNodeForPackage(OpenProtocolInit.class);
		_dimX = getPref(prefs, "DIMX", 400);
		_dimY = getPref(prefs, "DIMY", 600);
		_winState = getPref(prefs, "WINSTATE", JFrame.NORMAL);
		_locX = getPref(prefs, "LOCX", Integer.MAX_VALUE);
		_locY = getPref(prefs, "LOCY", Integer.MAX_VALUE);
		_dockRel = getPref(prefs, "DOCKREL", 0.8f);
	}
	
	private void saveState()
	{
		Preferences prefs = Preferences.userNodeForPackage(OpenProtocolInit.class);

		prefs.put("DIMX", Integer.toString(getWidth()));
		prefs.put("DIMY", Integer.toString(getHeight()));
		
		prefs.put("WINSTATE", Integer.toString(getExtendedState()));
		prefs.put("LOCX", Integer.toString(this.getLocation().x));
		prefs.put("LOCY", Integer.toString(this.getLocation().y));
		
		//getMainView().dock(getLogView(), SOUTH_REGION, _dockRel);

		DockingPort dockPort = getMainView().getDockingPort();
		if (dockPort != null) {
			Container container = getLogView().getParent().getParent();
	        if (container instanceof JSplitPane) {
	        	JSplitPane split = (JSplitPane)container;
	        	float curPos = (float)split.getDividerLocation();
	        	float maxPos = 0;
	        	if (split.getOrientation() == javax.swing.JSplitPane.VERTICAL_SPLIT) {
	        		maxPos = split.getHeight() - split.getDividerSize(); 
	        		//setDividerLocation((int)((double)(getHeight() - getDividerSize()) *  proportionalLocation));
     		    } else {
	        		maxPos = split.getWidth() - split.getDividerSize();
     		    }
	        	_dockRel = curPos / maxPos;
	    	}
		}
		prefs.put("DOCKREL", Float.toString(_dockRel));
		
	}
	
	public View getMainView() {
		if (_mainView == null) {
			_mainView = createView("main", "main");
			_mainView.setContentPane(getMainPane());
		}
		return _mainView;

	}

	public View getLogView() {
		if (_logView == null) {
			_logView = createView("log", "log");
			_logView.setContentPane(new JScrollPane(getLogArea()));
		}
		return _logView;
	}

	public JPanel getMainPane() {
		if (_mainPane == null) {
			_mainPane = new JPanel();
			_mainPane.setVisible(true);
		}
		return _mainPane;
	}

	public void setMIDMenuItemDisabled(IMIDMenuItemAction action) {
		//DefaultMenuBar bar = OpenProtocolInit.getInstance().getMainFrame().getDefaultMenuBar();
		getDefaultMenuBar().setItemDisabled(action);
	}
	
	public boolean getShowAllRevsChecked() {
		return getDefaultMenuBar().getShowAllRevsChecked();
	}

	public void updateMids() {
		getDefaultMenuBar().updateMids();
	}
	
	public void addMidMenuItem(IMIDMenuItemAction action)
	{
		getDefaultMenuBar().getMidActions().add(action);
	}
	
	public void closeAllMids() {
		getDefaultMenuBar().closeAllMids();
	}
	
	private DefaultMenuBar getDefaultMenuBar() {
		if (_menuBar == null) {
			_menuBar = new DefaultMenuBar();
		}
		return _menuBar;
	}

	public JTextArea getLogArea() {
		if (_logArea == null) {
			_logArea = new JTextArea();
		}
		return _logArea;
	}

	public Appender getLogger() {
		if (_logger == null) {
			_logger = new Appender() {

				public void addFilter(Filter arg0) {
					// TODO Auto-generated method stub

				}

				public void clearFilters() {
					// TODO Auto-generated method stub

				}

				public void close() {
					// TODO Auto-generated method stub

				}

				public void doAppend(LoggingEvent arg0) {
					getLogArea().append(arg0.getLevel().toString() + " - " + (String) arg0.getMessage()+"\n");
					getLogArea().setCaretPosition(getLogArea().getText().length());

				}

				public ErrorHandler getErrorHandler() {
					// TODO Auto-generated method stub
					return null;
				}

				public Filter getFilter() {
					// TODO Auto-generated method stub
					return null;
				}

				public boolean requiresLayout() {
					// TODO Auto-generated method stub
					return false;
				}

				public void setErrorHandler(ErrorHandler arg0) {
					// TODO Auto-generated method stub

				}

				public void setLayout(Layout arg0) {
					// TODO Auto-generated method stub

				}

				public Layout getLayout() {
					// TODO Auto-generated method stub
					return null;
				}

				public String getName() {
					// TODO Auto-generated method stub
					return null;
				}

				public void setName(String arg0) {
					// TODO Auto-generated method stub

				}

			};
		}
		return _logger;
	}

}
