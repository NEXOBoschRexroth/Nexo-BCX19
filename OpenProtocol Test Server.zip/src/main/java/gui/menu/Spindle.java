package gui.menu;

import java.awt.event.ActionEvent;
import java.util.LinkedList;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

public class Spindle extends JInternalFrame {

	private static Spindle _instance;

	private JComboBox _spnSelector;

	private JComponent _parent;

	private JPanel _contentPanel;

	private Spindle() {
		setTitle("Spindle");
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("pref:grow,default, default",
				"default, pref:grow, default, default, default");
		DefaultFormBuilder builder = new DefaultFormBuilder(layout);
		_contentPanel = builder.getPanel();
		this.setContentPane(_contentPanel);
		builder.add(getSpindleSelector(), cc.xyw(1, 1, 2));
		
		updateSpindles();
		
	}

	public static Spindle getInstance() {
		if (_instance == null) {
			_instance = new Spindle();
		}
		return _instance;
	}
	
	public int getSpindle() {
		return getSpindleSelector().getSelectedIndex();
	}

	private JComboBox getSpindleSelector() {
		if (_spnSelector == null) {
			_spnSelector = new JComboBox();
		}
		return _spnSelector;
	}
	
	private void updateSpindles() {
		getSpindleSelector().removeAllItems();
		int i = 0;
		for (i = 0; i < 10; i++) {
			getSpindleSelector().addItem(i);
		}
	}

	
	public void activate() {
		setVisible(true);
		getParent().add(this);
	}

	public void deactivate() {
		setVisible(false);
		getParent().remove(this);
	}

	public JComponent getParent() {

		return _parent;
	}

	public void setParent(JComponent _parent) {
		this._parent = _parent;
	}

	
}
