package gui.menu;

import java.awt.event.ActionEvent;
import java.util.LinkedList;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

public class Autosender extends JInternalFrame {

	private static Autosender _instance;

	private JComboBox _midSelector;

	private JComponent _parent;

	private JPanel _contentPanel;

	private JButton _addMid;

	private LinkedList<IMIDMenuItemAction> _autosendQ;

	private JTextArea _selectedMids;

	private JTextArea _loop;

	private JButton _clearButton;

	private JTextArea _pause;

	private Autosender() {
		setTitle("AutoSender");
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("pref:grow,default, default",
				"default, pref:grow, default, default, default");
		DefaultFormBuilder builder = new DefaultFormBuilder(layout);
		_contentPanel = builder.getPanel();
		this.setContentPane(_contentPanel);
		builder.add(getMidSelector(), cc.xyw(1, 1, 2));
		builder.add(getAddMidJButton(), cc.xy(3, 1));
		builder.add(new JScrollPane(getSelectedMIDs()), cc.xyw(1, 2,2));
		builder.add(getClearButton(), cc.xy(3, 2));
		builder.add(getLoop(), cc.xy(1, 3));
		builder.add(getPause(),cc.xy(2,3));
		builder.add(getStartButton(), cc.xy(3, 3));
		
	}

	private JTextArea getPause() {
		if (_pause == null){
			_pause = new JTextArea(1,5);
			_pause.setText("100");
		}
		return _pause;
	}

	private JButton getClearButton() {
		if (_clearButton == null) {
			_clearButton = new JButton(new AbstractAction("clear") {

				public void actionPerformed(ActionEvent arg0) {
					getAutoSendQ().clear();
					getSelectedMIDs().setText("");

				}
			});
		}
		return _clearButton;
	}

	private JTextArea getSelectedMIDs() {
		if (_selectedMids == null) {
			_selectedMids = new JTextArea(10, 100);
		}
		return _selectedMids;
	}

	private JButton getAddMidJButton() {
		if (_addMid == null) {
			_addMid = new JButton(new AbstractAction("add") {

				public void actionPerformed(ActionEvent arg0) {
					if ((IMIDMenuItemAction) getMidSelector().getSelectedItem() != null) {
						getAutoSendQ().addLast(
								(IMIDMenuItemAction) getMidSelector()
										.getSelectedItem());
						getSelectedMIDs().append(
								getMidSelector().getSelectedItem().toString()
										+ "\n");
						getSelectedMIDs().setCaretPosition(
								getSelectedMIDs().getText().length());
					}
				}
			});
		}
		return _addMid;
	}

	private JComboBox getMidSelector() {
		if (_midSelector == null) {
			_midSelector = new JComboBox();
		}
		return _midSelector;
	}

	private LinkedList<IMIDMenuItemAction> _activeMIDs;

	private JButton _startButton;

	public static Autosender getInstance() {
		if (_instance == null) {
			_instance = new Autosender();
		}
		return _instance;
	}

	private LinkedList<IMIDMenuItemAction> getActiveMIDs() {
		if (_activeMIDs == null) {
			_activeMIDs = new LinkedList<IMIDMenuItemAction>();
		}
		return _activeMIDs;
	}

	public void addActiveMID(IMIDMenuItemAction mid) {
		getActiveMIDs().add(mid);
		updateMids();
	}

	public void removeActiveMID(IMIDMenuItemAction mid) {
		getActiveMIDs().remove(mid);
		updateMids();
	}

	public void activate() {
		setVisible(true);
		getParent().add(this);
	}

	public void deactivate() {
		setVisible(false);
		getParent().remove(this);
	}

	private void updateMids() {
		getMidSelector().removeAllItems();
		for (IMIDMenuItemAction item : getActiveMIDs())
			getMidSelector().addItem(item);
	}

	public JComponent getParent() {

		return _parent;
	}

	public void setParent(JComponent _parent) {
		this._parent = _parent;
	}

	private LinkedList<IMIDMenuItemAction> getAutoSendQ() {
		if (_autosendQ == null) {
			_autosendQ = new LinkedList<IMIDMenuItemAction>();
		}
		return _autosendQ;
	}

	public JTextArea getLoop() {
		if (_loop == null) {
			_loop = new JTextArea(1,5);
			_loop.setText("10");
		}
		return _loop;
	}

	public JButton getStartButton() {
		if (_startButton == null) {
			_startButton = new JButton(new AbstractAction("start") {

				public void actionPerformed(ActionEvent arg0) {
					Thread t = new Thread(new Runnable(){

						public void run() {
							for (int i = Integer.valueOf(getLoop().getText()); i > 0 ; i--) {
								getLoop().setText(String.valueOf(i));
								for (IMIDMenuItemAction item : getAutoSendQ()) {
									item.doSendAction();
									try {
										Thread.sleep(Integer.valueOf(getPause().getText()));
									} catch (InterruptedException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
								}
							}
							
						}});
					t.start();


				}

			});
		}
		return _startButton;
	}

}
