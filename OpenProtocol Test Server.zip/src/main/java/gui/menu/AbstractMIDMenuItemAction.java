package gui.menu;

import gui.helper.InternalFrameHolder;
import gui.helper.MainFrameFactory;
import gui.helper.VERSIONS;

import java.lang.annotation.Annotation;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;

import run.OpenProtocolInit;

//import java.util.Formatter;
//import org.apache.log4j.Logger;
//import com.sun.org.omg.CORBA.VersionSpecHelper;

import manager.ConnectionManager;
import message.IMessage;
import message.INewIncomeMessageListener;
import message.OpenProtocolMessage;
import message.MIDVersionRevisions;
import actions.AbstractSendPanel;
import gui.menu.Spindle;

public abstract class AbstractMIDMenuItemAction implements IMIDMenuItemAction, INewIncomeMessageListener, IMessage {

	private boolean _active;

	private JComponent _parent;

	private JInternalFrame _internalFrame;
	
	private String _name;
	
	private int _pos = 0;
	
	private long _time; 
	
	protected MIDVersionRevisions _MIDVerRevs = new MIDVersionRevisions();
	
	
	public AbstractMIDMenuItemAction(JComponent parent, String name) {
		_parent = parent;
		_name = name;
		initialize();

	}

	private void initialize() {
		_active = false;

	}

	public void activate() {
		if (!isActive()) {
			setActive(true);
			getParent().add(getInternalFrame());
			getInternalFrame().setVisible(true);
			getDisplayedComponent().onShow();
			Autosender.getInstance().addActiveMID(this);
			ConnectionManager.getInstance().registerListener(this);
		}
	}

	public void deactivate() {
		if (isActive()) {
			setActive(false);
			getInternalFrame().setVisible(false);
			getParent().remove(getInternalFrame());
			Autosender.getInstance().removeActiveMID(this);
			ConnectionManager.getInstance().unregisterListener(this);
			// we might be called from the outside, so reset the menu check state, too
			OpenProtocolInit.getInstance().getMainFrame().setMIDMenuItemDisabled(this);
		}
	}
	
	public void onVersionChanged() {
		// reload current revisions...
		//AbstractSendPanel panel = (AbstractSendPanel)getDisplayedComponent();
		//panel.onVersionChanged();
	}
	
	public String getGroup() {
		// default implementation is to read the menu group name from the
		// class annotation (if any):
		Annotation annotation = this.getClass().getAnnotation(gui.menu.MenuGroup.class);
		if (annotation instanceof gui.menu.MenuGroup) {
			gui.menu.MenuGroup group = (gui.menu.MenuGroup)annotation;
			return group.name();
		}
		return "";		// no group
	}

	public boolean getEnabled() {
		// default: check, if this mid is available for the current version of the protocol
		if (_MIDVerRevs.size() != 0) {
			String[] revs = _MIDVerRevs.get(ConnectionManager.getInstance().getVersion());
			return (null != revs);
		}
		return true;
	}

	public String[] getMIDRevisions() {
		// default: return list of allowed revision codes based on the currently selected "VERSION"
		return _MIDVerRevs.get(ConnectionManager.getInstance().getVersion());
	}
	
	public String[] getAllMIDRevisions() {
		// get all possible MID revisions, regardless of current active version.
		ArrayList<String> ls = new ArrayList<String>();
		for (String revs[]: _MIDVerRevs.values()) {
			for (String rev: revs) {
				ls.add(rev);
			}
		}
		Set<String> set = new HashSet<String>(ls);
		String revs[] = new String[] {};
		String list[] = set.toArray(revs);
		Arrays.sort(list);
		return list;
	}

	public abstract AbstractSendPanel getDisplayedComponent();

	public boolean isActive() {
		return _active;
	}

	public void setActive(boolean _active) {
		this._active = _active;
	}

	public JComponent getParent() {
		return _parent;
	}

	public JInternalFrame getInternalFrame() {
		if (_internalFrame == null) {
			_internalFrame = MainFrameFactory.createMIDSendInternalFrame(this);
		}
		return _internalFrame;
	}

	public String getName() {
		return _name;
	}


	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return _name;
	}
	
	protected String extractInfo(int length, OpenProtocolMessage msg){
		String result =  msg.toString().substring(_pos, _pos+2) + "\t" + msg.toString().substring(_pos+2, _pos+length+2) +"\n";
		_pos += length + 2;
		return result;
	}
	protected String extractVal(int length, OpenProtocolMessage msg){
		String result =  msg.toString().substring(_pos, _pos+length);
		_pos += length;
		return result;
	}
	protected String extractHeader(OpenProtocolMessage msg){
		_pos = 0;
		return "L�nge: " + msg.getLength() + " ,MID: " + msg.getMid() + " ,Revision: " + msg.getRevision() + " ,No Ack Flag: " + msg.getNoAckFlag() +"\n";
	}

	public static String createHeader(int lenght, int mid, int revision, int nocAck) {
		if (ConnectionManager.getInstance().getVersion() == VERSIONS.BMW || ConnectionManager.getInstance().getVersion() == VERSIONS.FORD){
			int SpindleNo = Spindle.getInstance().getSpindle();
			return String.format("%04d", lenght) + String.format("%04d", mid) + String.format("%02d", SpindleNo) + String.format("%03d", revision) + "0000000";
		}
		return String.format("%04d", lenght) + String.format("%04d", mid) + String.format("%03d", revision) + String.format("%01d", nocAck) + "00000000";

	}
/*	
	public static String createHeader(int lenght, int mid, int revision, int nocAck, int Spindle){
		if (ConnectionManager.getInstance().getVersion() == VERSIONS.BMW || ConnectionManager.getInstance().getVersion() == VERSIONS.FORD){
			return String.format("%04d", lenght) + String.format("%04d", mid) + String.format("%02d", Spindle) + String.format("%03d", revision) + "0000000";
		}
		return String.format("%04d", lenght) + String.format("%04d", mid) + String.format("%03d", revision) + String.format("%01d", nocAck) + "00000000";

	}
*/	
	protected void setTimeStamp(){
		_time = System.currentTimeMillis();
	}
	
	protected String getTOF(){
		long delta = System.currentTimeMillis() - _time;
		return delta + " ms";
	}
	
}
