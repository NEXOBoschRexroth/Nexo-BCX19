package gui.menu;

import java.awt.event.ActionEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.nio.CharBuffer;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

public class Statistics extends JInternalFrame {

	interface ITighteningResult {
		public int getRes();

		public int getMMinus();

		public int getMPlus();

		public int getMP();

		public int getM();

		public int getWMinus();

		public int getWPlus();

		public int getW();

		public int getWP();

		public String getTimeStamp();

		public int getWGMinus();

		public int getWGPlus();

		public int getWG();

		public int CurMonMin();

		public int CurMonMax();

		public int CurMonVal();

	}

	abstract class AbstractTighteningResult implements ITighteningResult,
			Comparable<ITighteningResult> {

		public int compareTo(ITighteningResult arg0) {
			if ((arg0.getW()==0 ||arg0.getW() == getW())
					&& (arg0.getWMinus()==0 || arg0.getWMinus() == getWMinus())
					// && arg0.getWP() == getWP()
					&& (arg0.getWPlus()==0 || arg0.getWPlus() == getWPlus())
					&& (arg0.getM()==0 || arg0.getM() == getM())
					&& (arg0.getMMinus() == 0 || arg0.getMMinus() == getMMinus())
					// && arg0.getMP() == getMP()
					&& (arg0.getMPlus() == 0 || arg0.getMPlus() == getMPlus())
					&& arg0.getTimeStamp().equals(getTimeStamp())
					&& (arg0.getWG()==0 || arg0.getWG() == getWG())
					&& (arg0.getWGMinus()==0 || arg0.getWGMinus() == getWGMinus())
					&& (arg0.getWGPlus()==0 || arg0.getWGPlus() == getWGPlus())) {

				return 0;
			}
			return 1;
		}

	}

	class OPResult extends AbstractTighteningResult {

		String _fileText;

		public OPResult(String fileText) {
			_fileText = fileText;
		}

		private String subtext(int id, int length) {
			return _fileText.substring(_fileText.indexOf(String.valueOf(id)
					+ "\t") + 3, _fileText.indexOf(String.valueOf(id) + "\t")
					+ length + 3);
		}

		private int subtextInt(int id, int length) {
			return Integer.valueOf(subtext(id, length));
		}

		public int CurMonMax() {

			return subtextInt(33, 3);
		}

		public int CurMonMin() {

			return subtextInt(32, 3);
		}

		public int CurMonVal() {
			return subtextInt(34, 3);
		}

		public int getWG() {
			return subtextInt(31, 5);
		}

		public int getWGMinus() {
			return subtextInt(29, 5);
		}

		public int getWGPlus() {
			return subtextInt(30, 5);
		}

		public int getM() {
			return subtextInt(24, 6);
		}

		public int getMMinus() {
			return subtextInt(21, 6);
		}

		public int getMP() {
			return subtextInt(23, 6);
		}

		public int getMPlus() {
			return subtextInt(22, 6);
		}

		public int getRes() {
			return subtextInt(11, 1);
		}

		public String getTimeStamp() {

			return subtext(45, 19);
		}

		public int getW() {
			return subtextInt(28, 5);
		}

		public int getWMinus() {
			return subtextInt(25, 5);
		}

		public int getWP() {
			return subtextInt(27, 5);
		}

		public int getWPlus() {
			return subtextInt(26, 5);
		}

	}

	class FTPResult extends AbstractTighteningResult {

		String _fileText;

		public FTPResult(String fileText) {
			_fileText = fileText;
		}

		private int getRoundNM(String id) {
			return Math.abs((int) Math.round(getDoubleValueOf(id) * 100));
		}

		private String getValueOf(String id, int length) {
			if (_fileText.indexOf(id) == -1)
				return "0";
			return _fileText.substring(_fileText.indexOf(id) + id.length(),
					_fileText.indexOf(id) + length).trim();
		}

		private String getValueOf(String id) {
			return getValueOf(id, 12);
		}

		private double getDoubleValueOf(String id) {
			return Double.valueOf(getValueOf(id));
		}

		private int getIntValueOf(String id) {
			return (int) Math.round(getDoubleValueOf(id));
		}

		public int CurMonMax() {
			// TODO Auto-generated method stub
			return 0;
		}

		public int CurMonMin() {
			// TODO Auto-generated method stub
			return 0;
		}

		public int CurMonVal() {
			// TODO Auto-generated method stub
			return 0;
		}

		public int getWG() {
			// TODO Auto-generated method stub
			return getIntValueOf("WG ");
		}

		public int getWGMinus() {
			// TODO Auto-generated method stub
			return getIntValueOf("WG-");
		}

		public int getWGPlus() {
			// TODO Auto-generated method stub
			return getIntValueOf("WG+");
		}

		public int getM() {
			return getRoundNM("M ");
		}

		public int getMMinus() {
			// TODO Auto-generated method stub
			return getRoundNM("M- ");
		}

		public int getMP() {
			// TODO Auto-generated method stub
			return getRoundNM("MP ");
		}

		public int getMPlus() {
			// TODO Auto-generated method stub
			return getRoundNM("M+ ");
		}

		public int getRes() {
			// TODO Auto-generated method stub
			return 0;
		}

		public String getTimeStamp() {
			// TODO Auto-generated method stub
			return getValueOf("D ", 12) + ":" + getValueOf(" H ", 12);
		}

		public int getW() {
			// TODO Auto-generated method stub
			return getIntValueOf("W ");
		}

		public int getWMinus() {
			// TODO Auto-generated method stub
			return getIntValueOf("W- ");
		}

		public int getWP() {
			// TODO Auto-generated method stub
			return getIntValueOf("WP ");
		}

		public int getWPlus() {
			// TODO Auto-generated method stub
			return getIntValueOf("W+ ");
		}

	}

	private static Statistics _instance;

	private int _resultsCount = 0;

	JPanel _contentPanel;
	private JButton _resetButton;

	private JComponent _parent;

	private JLabel _resultsLabel;

	private JCheckBox _saveResCheckBox;

	private JTextField _directoryField;

	private JButton _buttonRunCompare;

	private JTextField _FTPdirectoryField;
	
	private JCheckBox _timing;

	private Statistics() {
		setTitle("Statistics");
		CellConstraints cc = new CellConstraints();
		FormLayout layout = new FormLayout("default, max(default;50px)",
				"default, default, default, default, default, default, default, default");
		DefaultFormBuilder builder = new DefaultFormBuilder(layout);
		_contentPanel = builder.getPanel();
		this.setContentPane(_contentPanel);
		builder.add(getResetButon(), cc.xy(1, 1));
		builder.add(new JLabel("Schraubergebnisse: "), cc.xy(1, 2));
		builder.add(getResultsLabel(), cc.xy(2, 2));
		builder.add(new JLabel("Save Results To File (Rev.5!): "), cc.xy(1, 3));
		builder.add(getSaveResCheckBox(), cc.xy(2, 3));
		builder.add(new JLabel("Directory: "), cc.xy(1, 4));
		builder.add(getDirectoryField(), cc.xy(2, 4));
		builder.add(new JLabel("Compare with FTP-Results: "), cc.xy(1, 5));
		builder.add(getButtonRunCompare(), cc.xy(2, 5));
		builder.add(new JLabel("FTP-Directory: "), cc.xy(1, 6));
		builder.add(getFtpDirectoryField(), cc.xy(2, 6));
		builder.add(new JLabel("Timing "), cc.xy(1, 7));
		builder.add(getTimingCheckBox(), cc.xy(2, 7));
		
		update();
	}

	private JButton getButtonRunCompare() {
		if (_buttonRunCompare == null) {
			_buttonRunCompare = new JButton(new AbstractAction("run...") {

				public void actionPerformed(ActionEvent arg0) {
					runComperation();

				}
			});
		}
		return _buttonRunCompare;
	}

	private void runComperation() {
		File opDir = new File(getDirectoryField().getText());
		File ftpDir = new File(getFtpDirectoryField().getText());
		boolean error = false;
		if (!opDir.exists() || !ftpDir.exists()) {
			Logger
					.getRootLogger()
					.error(
							"Kann vergleich nicht starten, angegebene Pfade �berpr�fen!");
			return;
		}
		if (opDir.listFiles().length != ftpDir.listFiles().length) {
			Logger
					.getRootLogger()
					.error(
							"Vergleich gescheitert, Verzeichnisinhalte unterschiedlich!");
			return;
		}
		for (int i = 0; i < opDir.listFiles().length; i++) {
			if (!opDir.listFiles()[i].isDirectory()) {
				Logger.getRootLogger().error(
						opDir.getAbsoluteFile().toString()
								+ " ist kein Verzeichnis!");
				return;

			}
			for (int j = 0; j < ftpDir.listFiles().length; j++) {
				if (!opDir.listFiles()[j].isDirectory()) {
					Logger.getRootLogger().error(
							ftpDir.getAbsoluteFile().toString()
									+ " ist kein Verzeichnis!");
					return;

				}
				if (opDir.listFiles()[i].getName().equals(
						ftpDir.listFiles()[j].getName())) {
					if (!compareDirs(opDir.listFiles()[i],
							ftpDir.listFiles()[j])) {
						error = true;
					}
				}
				if (j == ftpDir.listFiles().length) {
					Logger.getRootLogger().error(
							"kein Gegenst�ck gefunden zu "
									+ opDir.listFiles()[i].getName());
					error = true;
				}

			}
		}
		if (error) {
			Logger
					.getRootLogger()
					.error(
							"Vergleich nicht bestanden, Abweichende Ergebnisse gefunden!");
		} else {
			Logger.getRootLogger().info(
					"keine abweichenden Ergebnisse gefunden, vergleich OK!");
		}
	}

	private boolean compareDirs(File opDir, File ftpDir) {
		boolean error = false;
		if (opDir.listFiles().length != ftpDir.listFiles().length) {
			Logger.getRootLogger().error(
					"Vergleich gescheitert, Verzeichnisinhalte unterschiedlich! "
							+ opDir + " !=" + ftpDir);
			return false;
		}
		for (int i = 0; i < opDir.listFiles().length; i++) {
			for (int j = 0; j < ftpDir.listFiles().length; j++) {
				if (opDir.listFiles()[i].getName().substring(2, 14).equals(
						ftpDir.listFiles()[j].getName().substring(3, 15))) {
					try {
						if (!compareFiles(opDir.listFiles()[i], ftpDir
								.listFiles()[j])) {
							Logger.getRootLogger().error(
									"Fehler " + opDir.listFiles()[i] + "!="
											+ ftpDir.listFiles()[j]);
							error = true;
						} else {
							Logger.getRootLogger().info(
									"OK" + opDir.listFiles()[i] + "=="
											+ ftpDir.listFiles()[j]);
						}
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}

		return !error;
	}

	private boolean compareFiles(File opFile, File ftpFile) throws IOException {
		char[] opbuff = new char[(int) opFile.length()];
		char[] ftpbuff = new char[(int) ftpFile.length()];
		FileReader fr = new FileReader(opFile);
		fr.read(opbuff);
		fr.close();
		fr = new FileReader(ftpFile);
		fr.read(ftpbuff);
		fr.close();
		if (new OPResult(String.valueOf(opbuff)).compareTo(new FTPResult(String
				.valueOf(ftpbuff))) == 0) {
			return true;
		}
		return false;

	}

	private JTextField getFtpDirectoryField() {
		if (_FTPdirectoryField == null) {
			_FTPdirectoryField = new JTextField("C:\\daten\\results\\CH_00_1",
					20);
		}
		return _FTPdirectoryField;
	}

	public JTextField getDirectoryField() {
		if (_directoryField == null) {
			_directoryField = new JTextField("C:\\daten\\opresults", 20);
		}
		return _directoryField;
	}

	public JCheckBox getSaveResCheckBox() {
		if (_saveResCheckBox == null) {
			_saveResCheckBox = new JCheckBox();
		}
		return _saveResCheckBox;
	}
	
	public JCheckBox getTimingCheckBox(){
		if (_timing == null) {
			_timing = new JCheckBox();
		}
		return _timing;
	}

	private JLabel getResultsLabel() {
		if (_resultsLabel == null) {
			_resultsLabel = new JLabel();
		}
		return _resultsLabel;
	}

	public static Statistics getInstance() {
		if (_instance == null) {
			_instance = new Statistics();
		}
		return _instance;
	}

	private JButton getResetButon() {
		if (_resetButton == null) {
			_resetButton = new JButton(new AbstractAction("Reset") {

				public void actionPerformed(ActionEvent arg0) {
					fireReset();

				}
			});
		}
		return _resetButton;
	}

	public void incResults() {
		_resultsCount++;
		update();

	}

	protected void fireReset() {
		_resultsCount = 0;
		update();

	}

	private void update() {
		getResultsLabel().setText(String.valueOf(_resultsCount));
	}

	public void activate() {
		setVisible(true);
		getParent().add(this);
	}

	public void deactivate() {
		setVisible(false);
		getParent().remove(this);
	}

	public JComponent getParent() {

		return _parent;
	}

	public void setParent(JComponent _parent) {
		this._parent = _parent;
	}
}
