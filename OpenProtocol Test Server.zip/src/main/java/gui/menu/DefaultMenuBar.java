package gui.menu;

import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.AbstractAction;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JSeparator;
import javax.swing.MenuElement;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import manager.ConnectionManager;

public class DefaultMenuBar extends JMenuBar {

	private JMenu _settings;
	
	private JCheckBoxMenuItem _miShowAllMids;

	private JCheckBoxMenuItem _miShowAllRevs;
	
	private LinkedList<IMIDMenuItemAction> _midActions;
	
	public DefaultMenuBar() {
		initialize();
	}

	private void initialize() {
		this.add(getJMenuSettings());
	}
	
	private JMenu getJMenuSettings(){
		if (_settings == null){
			_settings = new JMenu("Settings");
			final JCheckBoxMenuItem item0 = new JCheckBoxMenuItem("autosender");
			item0.addChangeListener(new ChangeListener(){

				public void stateChanged(ChangeEvent arg0) {
					if (item0.isSelected()){
						Autosender.getInstance().activate();
					}else {
						Autosender.getInstance().deactivate();
					}
					
				}
				
			});
			_settings.add(item0);
			
			final JCheckBoxMenuItem item1 = new JCheckBoxMenuItem("statistics");
			item1.addItemListener(new ItemListener(){

				public void itemStateChanged(ItemEvent arg0) {
					if (item1.isSelected()){
						Statistics.getInstance().activate();
					}else {
						Statistics.getInstance().deactivate();
					}
					
				}});

			_settings.add(item1);

			final JCheckBoxMenuItem item2 = new JCheckBoxMenuItem("spindle");
			item2.addItemListener(new ItemListener(){

				public void itemStateChanged(ItemEvent arg0) {
					if (item2.isSelected()){
						Spindle.getInstance().activate();
					}else {
						Spindle.getInstance().deactivate();
					}
					
				}});

			_settings.add(item2);
		
			final JCheckBoxMenuItem item3 = new JCheckBoxMenuItem("hide alive");
			item3.addItemListener(new ItemListener(){

				public void itemStateChanged(ItemEvent arg0) {
					if (item3.isSelected()){
						// TODO: Spindle.getInstance().activate();
						ConnectionManager.getInstance().setHideAlive(true);
					}else {
						// TODO: Spindle.getInstance().deactivate();
						ConnectionManager.getInstance().setHideAlive(false);
					}
					
				}});
			_settings.add(item3);
			
			_miShowAllMids = new JCheckBoxMenuItem("Show all MIDs");
			_miShowAllMids.addItemListener(new ItemListener(){
				public void itemStateChanged(ItemEvent arg0) {
					updateMids();	
				}});
			_settings.add(_miShowAllMids);

			_miShowAllRevs = new JCheckBoxMenuItem("Show all Revisions");
			_miShowAllRevs.addItemListener(new ItemListener(){
				public void itemStateChanged(ItemEvent arg0) {
					updateMids();	
				}});
			_settings.add(_miShowAllRevs);
			
		}
		return _settings;
	}

	public boolean getShowAllRevsChecked() {
		return _miShowAllRevs.isSelected();
	}
	
	public LinkedList<IMIDMenuItemAction> getMidActions() {
		if (_midActions == null){
			_midActions = new LinkedList<IMIDMenuItemAction>();
		}
		return _midActions;
	}

//	public void setMidActions(LinkedList<IMIDMenuItemAction> actions) {
//		_midActions = actions;
//	}
	private LinkedList<JMenu> _midMenus = new LinkedList<JMenu>();
	//private JMenu _midMenu = null;
	private HashMap<IMIDMenuItemAction, JCheckBoxMenuItem> _menuItemMap;
	
	public void updateMids() {
		IMIDMenuItemAction first = getMidActions().getFirst();
		if (_midMenus.size() == 0) {
			JMenu jm1 = new JMenu("MIDs 0-99");
			JMenu jm2 = new JMenu("MIDs 100-9999");
			_midMenus.add(jm1);
			_midMenus.add(jm2);
			this.add(jm1);
			this.add(jm2);

			_menuItemMap = new HashMap<IMIDMenuItemAction, JCheckBoxMenuItem>();
			String currentGroup = first.getGroup(); 
			for (final IMIDMenuItemAction action : getMidActions()){
	
				final JCheckBoxMenuItem item = new  JCheckBoxMenuItem(action.getName());
				_menuItemMap.put(action, item);
				boolean fEnabled = action.getEnabled();
				if (_miShowAllMids.isSelected()) {			// Alle MIDs anzeigen oder nur die auch zur aktuellen Protokoll-Version passen?
					item.setEnabled(true);
				}
				else {
					item.setEnabled(fEnabled);
				}
				item.addChangeListener(new ChangeListener(){
	
					public void stateChanged(ChangeEvent arg0) {
						if (item.isSelected()){
							action.activate();
							
						} else {
							action.deactivate();
						}
						
					}});
				JMenu jm = null;
				String mid = action.getClass().getSimpleName().substring(3);
				if (Integer.parseInt(mid) < 100) jm = jm1;
				else jm = jm2;
				if (0 != currentGroup.compareTo(action.getGroup())) {
					jm.add(new JSeparator());
					currentGroup = action.getGroup();
				}
				jm.add(item);
			}
		}
		else {
			// update state only
			for (final IMIDMenuItemAction action : getMidActions()){
				action.onVersionChanged();
				JCheckBoxMenuItem item = _menuItemMap.get(action);
				boolean fEnabled = action.getEnabled();
				if (_miShowAllMids.isSelected()) {			// Alle MIDs anzeigen oder nur die auch zur aktuellen Protokoll-Version passen?
					item.setEnabled(true);
				}
				else {
					item.setEnabled(fEnabled);
				}
			}
		}
	}
	
	public void closeAllMids() {
		if (_menuItemMap == null) return;
		IMIDMenuItemAction first = getMidActions().getFirst();
		for (final IMIDMenuItemAction action : getMidActions()){
			JCheckBoxMenuItem item = _menuItemMap.get(action);
			action.deactivate();
		}
	}
	
	public void setItemDisabled(IMIDMenuItemAction item) {
		if (_midMenus.size() == 0) return;
		for (JMenu jm: _midMenus) {
			for (Component me: jm.getMenuComponents()) {
				if (me.getClass() == JCheckBoxMenuItem.class) {
					JCheckBoxMenuItem i = (JCheckBoxMenuItem)me;
					if (i.getText() == item.getName()) {
						i.setSelected(false);		// note: this does not trigger an actionevent!
					}
				}
			}
		}
	}
}
