package gui.menu;

import javax.swing.JComponent;

import message.INewIncomeMessageListener;

public interface IMIDMenuItemAction extends INewIncomeMessageListener{
	
	public void activate();
	
	public void deactivate();
	
	public JComponent getDisplayedComponent();
	
	public void doSendAction();
	
	public void doCloseAction();
	
	public String getName();
	
	public boolean getEnabled();
	
	public String getGroup();	
	
	public void onVersionChanged();
	
	public String[] getMIDRevisions();
	
	public String[] getAllMIDRevisions();
}
