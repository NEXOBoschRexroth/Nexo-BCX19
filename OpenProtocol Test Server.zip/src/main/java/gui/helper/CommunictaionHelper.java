package gui.helper;

public class CommunictaionHelper {

	public static int byteArrayToInt(byte[] array, int offset, int length) {
		String s = new String();

		for (int i = offset; i < offset + length; i++) {
			s += String.valueOf((char) array[i]);
		}
		try {
			return Integer.valueOf(s);
		} catch (NumberFormatException e) {
			return 0;
		}

	}
}
