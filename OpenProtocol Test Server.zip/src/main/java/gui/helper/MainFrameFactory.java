package gui.helper;

import gui.menu.IMIDMenuItemAction;

import javax.swing.BorderFactory;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.event.InternalFrameEvent;


public class MainFrameFactory {

	public static JInternalFrame createMIDSendInternalFrame(IMIDMenuItemAction midAction){
		InternalFrameHolder frame = new InternalFrameHolder(midAction); //JInternalFrame();
		JComponent comp = midAction.getDisplayedComponent();
		comp.setBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2));
		frame.setContentPane(comp);
				
		//frame.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		frame.addInternalFrameListener(new javax.swing.event.InternalFrameAdapter() {
			public void internalFrameClosing(InternalFrameEvent e) {
				// notify that we are closing
				InternalFrameHolder frame = (InternalFrameHolder)e.getInternalFrame();
				frame._midAction.deactivate();
		    }
		});		
		
		frame.setVisible(true);
		frame.setTitle(midAction.getClass().getSimpleName() + " " + midAction.getName());
		frame.setClosable(true);
		return frame;
	}

}
