package gui.helper;

public enum VERSIONS {
	NONE, REXROTH, BMW, FORD
}
