package gui.helper;

import gui.menu.IMIDMenuItemAction;

import javax.swing.JInternalFrame;

public class InternalFrameHolder extends JInternalFrame {
	private static final long serialVersionUID = -2731984520171945109L;
	protected IMIDMenuItemAction _midAction;
	public InternalFrameHolder(IMIDMenuItemAction midAction)
	{
		_midAction = midAction;
	}
}
