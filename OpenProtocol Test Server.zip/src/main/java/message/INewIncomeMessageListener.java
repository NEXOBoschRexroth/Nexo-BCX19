package message;

public interface INewIncomeMessageListener {

	public void fireNewMessageEvent(OpenProtocolMessage opm);
}
