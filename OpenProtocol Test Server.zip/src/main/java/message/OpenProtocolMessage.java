package message;
import manager.ConnectionManager;
import gui.helper.CommunictaionHelper;
import gui.helper.VERSIONS;


public class OpenProtocolMessage {

	private boolean _correct = true;
	
	private int _mid;
	
	private int _length;
	
	private int _revision;
	
	private int _noAckFlag;
	
	private int _spindle;
	
	private byte[] _msg;
	
	public OpenProtocolMessage(byte[] message) {
		processMessage(message);
	}

	private void processMessage(byte[] message) {
		if (ConnectionManager.getInstance().getVersion() == VERSIONS.REXROTH){
			setLength(CommunictaionHelper.byteArrayToInt(message, 0, 4));
			setMid(CommunictaionHelper.byteArrayToInt(message, 4, 4));
			setRevision(CommunictaionHelper.byteArrayToInt(message, 8, 3));
			setNoAckFlag(CommunictaionHelper.byteArrayToInt(message, 11, 1));
		} else if (ConnectionManager.getInstance().getVersion() == VERSIONS.BMW || ConnectionManager.getInstance().getVersion() == VERSIONS.FORD ){
			setLength(CommunictaionHelper.byteArrayToInt(message, 0, 4));
			setMid(CommunictaionHelper.byteArrayToInt(message, 4, 4));
			setSpindle(CommunictaionHelper.byteArrayToInt(message, 8, 2));
			setRevision(CommunictaionHelper.byteArrayToInt(message, 10, 3));
			//setNoAckFlag(CommunictaionHelper.byteArrayToInt(message, 11, 1));
		
		}
		byte[] msg = new byte[getLength()-20];
		System.arraycopy(message, 20, msg, 0, getLength()-20);
		setMsg(msg);
		
	}

	public boolean isCorrect() {
		return _correct;
	}

	public void setCorrect(boolean _correct) {
		this._correct = _correct;
	}

	public int getLength() {
		return _length;
	}

	public void setLength(int _length) {
		this._length = _length;
	}

	public int getMid() {
		return _mid;
	}

	public void setMid(int _mid) {
		this._mid = _mid;
	}

	public int getRevision() {
		return _revision;
	}

	public void setRevision(int _revision) {
		this._revision = _revision;
	}

	public int getNoAckFlag() {
		return _noAckFlag;
	}

	public void setNoAckFlag(int ackFlag) {
		_noAckFlag = ackFlag;
	}

	public byte[] getMsg() {
		return _msg;
	}
	@Override
	public String toString(){
		return new String(getMsg());
	}

	public void setMsg(byte[] _msg) {
		
		this._msg = _msg;
	}

	public int getSpindle() {
		return _spindle;
	}

	public void setSpindle(int _spindle) {
		this._spindle = _spindle;
	}
}
