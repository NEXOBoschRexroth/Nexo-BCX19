package message;

import java.util.EnumMap;
import gui.helper.VERSIONS;

public class MIDVersionRevisions extends EnumMap<VERSIONS, String[]> 
{
	private static final long serialVersionUID = -2815766318356121735L;

	public MIDVersionRevisions() {
		super(VERSIONS.class);
	}
}

