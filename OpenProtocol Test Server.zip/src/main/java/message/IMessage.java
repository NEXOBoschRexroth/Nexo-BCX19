package message;

public interface IMessage {

	public String[] getMIDRevisions();	

}
