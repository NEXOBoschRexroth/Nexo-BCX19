package run;

import gui.menu.Autosender;
import gui.menu.IMIDMenuItemAction;
import gui.menu.Statistics;
import gui.menu.Spindle;
import gui.run.MainFrame;

import java.util.LinkedList;
import manager.ConnectionManager;
import mids.*;

import org.apache.log4j.Logger;

public class OpenProtocolInit {

	LinkedList<IMIDMenuItemAction> mids = new LinkedList<IMIDMenuItemAction>();

	
	private MainFrame _mainFrame;
	private static OpenProtocolInit _instance;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		_instance = new OpenProtocolInit();
		_instance.run();
	}

	public static OpenProtocolInit getInstance() {
		return _instance;
	}

	public void run() {
		getMainFrame();
		
		initializeMIDs();
		Autosender.getInstance().setParent(getMainFrame().getMainPane());
		Statistics.getInstance().setParent(getMainFrame().getMainPane());
		Spindle.getInstance().setParent(getMainFrame().getMainPane());
	}

	public void closeAllMids()
	{
		// MID0001 frame closed - close all open frames and disconnect.
		getMainFrame().closeAllMids();
		ConnectionManager.getInstance().disconnect();
	}

	private void initializeMIDs() {
		
		getMainFrame().addMidMenuItem(new MID0001(getMainFrame().getMainPane(), "Communication Start (1)"));
		getMainFrame().addMidMenuItem(new MID0003(getMainFrame().getMainPane(), "Communication Stop (3)"));
		getMainFrame().addMidMenuItem(new MID0008(getMainFrame().getMainPane(), "Spindle connect status subscribe (8)"));
		getMainFrame().addMidMenuItem(new MID0009(getMainFrame().getMainPane(), "Spindle connect status unsubscribe (9)"));
		getMainFrame().addMidMenuItem(new MID0010(getMainFrame().getMainPane(), "Parameter Set number upload Request (10)"));
		getMainFrame().addMidMenuItem(new MID0012(getMainFrame().getMainPane(), "Parameter Set data upload Request (12)"));
		getMainFrame().addMidMenuItem(new MID0014(getMainFrame().getMainPane(), "Parameter set selected subscribe (14)"));
		getMainFrame().addMidMenuItem(new MID0017(getMainFrame().getMainPane(), "Parameter set selected unsubscribe (17)"));
		getMainFrame().addMidMenuItem(new MID0018(getMainFrame().getMainPane(), "Select Parameter set (18)"));
		getMainFrame().addMidMenuItem(new MID0019(getMainFrame().getMainPane(), "Set Parameter Set Batch Size (19)"));
		getMainFrame().addMidMenuItem(new MID0020(getMainFrame().getMainPane(), "Reset Parameter Set Batch Size (20)"));
		getMainFrame().addMidMenuItem(new MID0021(getMainFrame().getMainPane(), "Disable Parameter Set batch counter (21)"));
		getMainFrame().addMidMenuItem(new MID0030(getMainFrame().getMainPane(), "Batch number upload request (30)"));
		getMainFrame().addMidMenuItem(new MID0040(getMainFrame().getMainPane(), "Tool Data (40)"));
		getMainFrame().addMidMenuItem(new MID0042(getMainFrame().getMainPane(), "Disable Tool (42)"));
		getMainFrame().addMidMenuItem(new MID0043(getMainFrame().getMainPane(), "Enable Tool (43)"));
		getMainFrame().addMidMenuItem(new MID0050(getMainFrame().getMainPane(), "Set ID in tool (50)"));
		getMainFrame().addMidMenuItem(new MID0051(getMainFrame().getMainPane(), "ID Subscribe (51)"));
		getMainFrame().addMidMenuItem(new MID0054(getMainFrame().getMainPane(), "ID Unsubscribe (54)"));
		getMainFrame().addMidMenuItem(new MID0060(getMainFrame().getMainPane(), "Subscribe Results (60)"));
		getMainFrame().addMidMenuItem(new MID0063(getMainFrame().getMainPane(), "Unsubscribe Results (63)"));
		getMainFrame().addMidMenuItem(new MID0064(getMainFrame().getMainPane(), "Old Tightening Result (64)"));
		getMainFrame().addMidMenuItem(new MID0070(getMainFrame().getMainPane(), "Alarm Subscribe (70)"));
		getMainFrame().addMidMenuItem(new MID0073(getMainFrame().getMainPane(), "Alarm Unsubscribe (73)"));
		getMainFrame().addMidMenuItem(new MID0078(getMainFrame().getMainPane(), "Acknowledge all Alarms remotely (78)"));
		getMainFrame().addMidMenuItem(new MID0080(getMainFrame().getMainPane(), "Read time upload request (80)"));
		getMainFrame().addMidMenuItem(new MID0082(getMainFrame().getMainPane(), "Set time in controller (82)"));

		getMainFrame().addMidMenuItem(new MID0100(getMainFrame().getMainPane(), "Subscribe Multispindle Results (100)"));
		getMainFrame().addMidMenuItem(new MID0103(getMainFrame().getMainPane(), "Unsubscribe Multispindle Results (103)"));
		getMainFrame().addMidMenuItem(new MID0110(getMainFrame().getMainPane(), "Send Text to Compact (110)"));
		getMainFrame().addMidMenuItem(new MID0111(getMainFrame().getMainPane(), "Send Text to Graph (111)"));
		getMainFrame().addMidMenuItem(new MID0113(getMainFrame().getMainPane(), "Flash green Light on Tool (113)"));
		getMainFrame().addMidMenuItem(new MID0150(getMainFrame().getMainPane(), "Send ID (150)"));
		getMainFrame().addMidMenuItem(new MID0400(getMainFrame().getMainPane(), "Automatic/Manual Mode Subscribe (400)"));
		getMainFrame().addMidMenuItem(new MID0403(getMainFrame().getMainPane(), "Automatic/Manual Mode Unsubscribe (403)"));
		getMainFrame().addMidMenuItem(new MID0404(getMainFrame().getMainPane(), "Automatic/Manual mode selection (404)"));
		getMainFrame().addMidMenuItem(new MID0410(getMainFrame().getMainPane(), "Get AutoDisable Settings (410)"));
		
		getMainFrame().addMidMenuItem(new MID0500(getMainFrame().getMainPane(), "Signals out change subscribe (500)"));
		getMainFrame().addMidMenuItem(new MID0503(getMainFrame().getMainPane(), "Signals out change unsubscribe (503)"));
		getMainFrame().addMidMenuItem(new MID0504(getMainFrame().getMainPane(), "Set Signals In (504)"));
		getMainFrame().addMidMenuItem(new MID0510(getMainFrame().getMainPane(), "HVO Button change subscribe (510)"));
		getMainFrame().addMidMenuItem(new MID0513(getMainFrame().getMainPane(), "HVO Button change unsubscribe (513)"));
		getMainFrame().addMidMenuItem(new MID0515(getMainFrame().getMainPane(), "Set HVO Signal (515)"));
		getMainFrame().addMidMenuItem(new MID0520(getMainFrame().getMainPane(), "Socket chamber change subscribe (520)"));
		getMainFrame().addMidMenuItem(new MID0523(getMainFrame().getMainPane(), "Socket chamber change unsubscribe (523)"));
		getMainFrame().addMidMenuItem(new MID0524(getMainFrame().getMainPane(), "Socket chamber selection  (524)"));
		getMainFrame().addMidMenuItem(new MID0554(getMainFrame().getMainPane(), "Job Result Subscribe (554)"));
		getMainFrame().addMidMenuItem(new MID0557(getMainFrame().getMainPane(), "Job Result Unsubscribe (557)"));
		getMainFrame().addMidMenuItem(new MID0570(getMainFrame().getMainPane(), "Job Enable (570)"));
		getMainFrame().addMidMenuItem(new MID0571(getMainFrame().getMainPane(), "Job Start (571)"));
		getMainFrame().addMidMenuItem(new MID0573(getMainFrame().getMainPane(), "Job Select (573)"));
		getMainFrame().addMidMenuItem(new MID0574(getMainFrame().getMainPane(), "Job Manipulate (574)"));
		
		getMainFrame().addMidMenuItem(new MID9999(getMainFrame().getMainPane(), "Keep Alive (9999)"));
		
		//getMainFrame().getDefaultMenuBar().setMidActions(mids);
		getMainFrame().updateMids();
		getMainFrame().setVisible(true);

		
	}


	public MainFrame getMainFrame() {
		if (_mainFrame == null){
			_mainFrame = new MainFrame();
			Logger.getRootLogger().addAppender(_mainFrame.getLogger());
		}
		return _mainFrame;
	}

}
