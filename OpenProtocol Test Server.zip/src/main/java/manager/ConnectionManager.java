package manager;

import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.LinkedList;

import org.apache.log4j.Logger;

import message.INewIncomeMessageListener;
import message.OpenProtocolMessage;

import run.OpenProtocolInit;


public class ConnectionManager {

	
	private boolean connected;

	private LinkedList<OpenProtocolMessage> messages;
	
	private LinkedList<INewIncomeMessageListener> _listeners;
	
	private Socket _socket;
	
	private long lastMessageSentStamp;
	
	private boolean _alive = true;
	
	private boolean _hideAlive = false;
	
	private VERSIONS _version = VERSIONS.NONE;

	
	class KeepAliveThread implements Runnable{
		public void run() {
			while (_alive){
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				if (System.currentTimeMillis()-getLastMessageSentStamp()>10000 && isConnected()){
					sendMessage(AbstractMIDMenuItemAction.createHeader(20, 9999, 1, 0));
				}
			}
			
		}
	}
	
	class ConnectionListener implements Runnable {

		

		public void run() {
			try {
				int c;
				while (_alive) {
					byte b = (byte) getSocket().getInputStream().read();
					if (b!= -1){
					c = getSocket().getInputStream().available();
					byte[] rcv = new byte[c];
					getSocket().getInputStream().read(rcv, 0, c);
					byte[] msg = new byte[c + 1];
					msg[0] = b;
					System.arraycopy(rcv, 0, msg, 1, c);
					eventIncomingMessage(msg);}
					else {
						_alive = false;
						Logger.getRootLogger().info("Connection Closed by server");
					}
				}
			} catch (IOException e) {
				Logger.getRootLogger().info("Connection Reseted from server");
			}
			resetConnection();
		}

		public Socket getSocket() {
			return _socket;
		}

	}

	private void eventIncomingMessage(byte[] msg) {
		String tmp = new String(msg);
		int mid = 0;
		try { mid = Integer.valueOf(tmp.substring(4, 8)); } finally {}  
		if (mid != 9999 || !_hideAlive) {
			if (getVersion() == VERSIONS.BMW || getVersion() == VERSIONS.FORD) {
				Logger.getRootLogger().info("rcv-msg: " 
						+ tmp.substring(0, 4) + "|" 	// length
						+ tmp.substring(4, 8) + "|" 	// mid
						+ tmp.substring(8, 10) + "|" 	// spindle
						+ tmp.substring(10, 13) + "|" 	// rev
						+ tmp.substring(13, 20) + "["	// spare
						+ tmp.substring(20) + "]");
			} else {
				// unknown, standard & Rexroth
				Logger.getRootLogger().info("rcv-msg: " 
						+ tmp.substring(0, 4) + "|" 	// length
						+ tmp.substring(4, 8) + "|" 	// mid
						+ tmp.substring(8, 11) + "|" 	// rev
						+ tmp.substring(11, 12) + "|"	// noAck 
						+ tmp.substring(12, 20) + "["	// spare
						+ tmp.substring(20) + "]");
			}
		}
		OpenProtocolMessage opm = new OpenProtocolMessage(msg);
		if (opm.isCorrect())
			getMessages().addLast(opm);
		if (opm.getMid() == 4){
			Logger.getRootLogger().error(opm.toString().substring(0, 4) + "\t" + opm.toString().substring(4, 6));
		}
		if (opm.getMid() == 5){
			Logger.getRootLogger().info(opm.toString().substring(0, 4) + "\t" + " accepted by Controller ");
		}

		for (INewIncomeMessageListener listener : getListeners()){
			try {
				listener.fireNewMessageEvent(opm);
			}
			catch (Exception e) {
				Logger.getRootLogger().warn(listener.getClass().getSimpleName() + ": Fehler beim Parsen!", e);
			}
		}
	}

	
	
	private void resetConnection() {
		setConnected(false);
		
	}

	private static ConnectionManager _instance;

	private ConnectionManager() {
		// TODO entferne bla 
		// WARNING
		
	}

	public static ConnectionManager getInstance() {
		if (_instance == null){
			_instance = new ConnectionManager();
		}
		return _instance;
	}
	
	public void disconnect(){
		_alive = false;
		try {
			getSocket().close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		resetConnection();
	}
	

	public boolean connect(InetAddress addr, int port) {
		try {
			_alive = true;
			Logger.getRootLogger().info("Connecting to " + addr +":"+port);
			setSocket(new Socket(addr, port));
			Thread t = new Thread(new ConnectionListener());
			t.start();
			Thread u = new Thread(new KeepAliveThread());
			u.start();
			Logger.getRootLogger().info("Connected.");
			setConnected(true);
		} catch (IOException e) {
			Logger.getRootLogger().error(addr + " ist not reachable");
			return false;
		}
		return true;
	}

	public boolean isConnected() {
		return connected;
	}

	public void setConnected(boolean connected) {
		this.connected = connected;
	}

	public LinkedList<OpenProtocolMessage> getMessages() {
		if (messages == null) {
			messages = new LinkedList<OpenProtocolMessage>();
		}
		return messages;
	}

	public LinkedList<INewIncomeMessageListener> getListeners() {
		if (_listeners == null){
			_listeners = new LinkedList<INewIncomeMessageListener>();
		}
		return _listeners;
	}
	
	public void registerListener(INewIncomeMessageListener listener){
		getListeners().add(listener);
	}
	
	public void unregisterListener(INewIncomeMessageListener listener){
		getListeners().remove(listener);
	}
	
	public void sendMessage(String message)
	{
		if (!isConnected()) {
			Logger.getRootLogger().error("NOT connected. Cannot send!");
			return;
		}
		try {
			message+= " ";
			byte[] msg = message.getBytes();
			msg[msg.length-1] = 0;
			
			//Logger.getRootLogger().info("sending: " + message);
			String tmp = message;
			int mid = 0;
			try { mid = Integer.valueOf(tmp.substring(4, 8)); } finally {}  
			if (mid != 9999 || !_hideAlive) {
				if (getVersion() == VERSIONS.BMW || getVersion() == VERSIONS.FORD) {
					Logger.getRootLogger().info("sending: " 
							+ tmp.substring(0, 4) + "|" 	// length
							+ tmp.substring(4, 8) + "|" 	// mid
							+ tmp.substring(8, 10) + "|" 	// spindle
							+ tmp.substring(10, 13) + "|" 	// rev
							+ tmp.substring(13, 20) + "["	// spare
							+ tmp.substring(20) + "]");
				} else {
					// unknown, standard & Rexroth
					Logger.getRootLogger().info("sending: " 
							+ tmp.substring(0, 4) + "|" 	// length
							+ tmp.substring(4, 8) + "|" 	// mid
							+ tmp.substring(8, 11) + "|" 	// rev
							+ tmp.substring(11, 12) + "|"	// noAck 
							+ tmp.substring(12, 20) + "["	// spare
							+ tmp.substring(20) + "]");
				}
			}
			getSocket().getOutputStream().write(msg);
			getSocket().getOutputStream().flush();
			resetLastMessageSentStamp();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			Logger.getRootLogger().error(e.getMessage());
			disconnect();
		}catch (NullPointerException e){
			Logger.getRootLogger().error(e.getMessage());
		}
	}

	public synchronized Socket getSocket() {
		return _socket;
	}

	public void setSocket(Socket _socket) {
		this._socket = _socket;
	}

	public long getLastMessageSentStamp() {
		return lastMessageSentStamp;
	}

	public void resetLastMessageSentStamp() {
		this.lastMessageSentStamp = System.currentTimeMillis();
	}

	public void setHideAlive(boolean newVal) {
		_hideAlive = newVal;
	}

	public VERSIONS getVersion() {
		return _version;
	}



	public void setVersion(VERSIONS _version) {
		this._version = _version;
	}



}
