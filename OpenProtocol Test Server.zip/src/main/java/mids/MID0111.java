package mids;

import java.util.ArrayList;

import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0012.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;

@gui.menu.MenuGroup(name="Various")
public class MID0111 extends AbstractMIDMenuItemAction {

	class InnerPanel extends AbstractSendPanel {

		private ArrayList<JTextField> _txtLines;
		private JTextField _txtSeconds;
		private JCheckBox  _cbRemoval;

		private JPanel _mainPanel;

		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null) {
				_mainPanel = getBuilder().getPanel();

				getBuilder().add(new JLabel("Duration"), _cc.xy(1, 1));
				getBuilder().add(getSeconds(), _cc.xy(2, 1));

				getBuilder().add(new JLabel("Wait Ack"), _cc.xy(1, 2));
				getBuilder().add(getRemoval(), _cc.xy(2, 2));

				for (int i = 0; i < 4; i++) {
					getBuilder().add(new JLabel("Line #" + Integer.toString(i+1)), _cc.xy(1, 3+i));
					getBuilder().add(getLine(i), _cc.xy(2, 3+i));
				}
			}

			return _mainPanel;
		}

		public JTextField getLine(int idx) {
			if (_txtLines == null) {
				_txtLines = new ArrayList<JTextField>();
				for (int i = 0; i < 4; i++) {
					JTextField txt = new JTextField(25);
					if (i == 0) txt.setText("TEXT HEADER");
					_txtLines.add(txt);
				}

			}
			return _txtLines.get(idx);
		}
		
		public JTextField getSeconds() {
			if (_txtSeconds == null) {
				_txtSeconds = new JTextField(4);
				_txtSeconds.setText("10");

			}
			return _txtSeconds;
		}
		
		public JCheckBox getRemoval() {
			if (_cbRemoval == null) {
				_cbRemoval = new JCheckBox("Check for manual ack.");
			}
			return _cbRemoval;
		}
		
	}

	private InnerPanel _interactionPanel;

	public MID0111(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null) {
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;
	}

	public void doCloseAction() {

	}

	public void doSendAction() {

		String msg = createHeader(137, 111, _interactionPanel.getSelectedCmdRev(), 0)
				+ "01" + String.format("%04d", Integer.valueOf(_interactionPanel.getSeconds().getText()))
				+ "02" + (_interactionPanel.getRemoval().isSelected() ? "1" : "0");
		for (int i = 0; i < 4; i++) {
			msg = msg + String.format("%02d%-25.25s", i+3, _interactionPanel.getLine(i).getText()); 
		}
		ConnectionManager.getInstance().sendMessage(msg);

	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
	}

}
