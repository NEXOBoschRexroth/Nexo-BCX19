package mids;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0012.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;

@gui.menu.MenuGroup(name="ParameterSet")
public class MID0019 extends AbstractMIDMenuItemAction {

	class InnerPanel extends AbstractSendPanel {

		private JTextField _psetId;

		private JTextField _BatchSize;
		
		private JTextField _BatchSizeNOK;

		private JPanel _mainPanel;

		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null) {
				_mainPanel = getBuilder().getPanel();

				getBuilder().add(new JLabel("Programm ID"), _cc.xy(1, 1));
				getBuilder().add(getPsetId(), _cc.xy(2, 1));
				getBuilder().add(new JLabel("Batch Size OK"), _cc.xy(1, 2));
				getBuilder().add(getBatchSize(), _cc.xy(2, 2));
				getBuilder().add(new JLabel("Batch Size NOK"), _cc.xy(1, 3));
				getBuilder().add(getBatchSizeNOK(), _cc.xy(2, 3));
			}

			return _mainPanel;
		}

		public JTextField getPsetId() {
			if (_psetId == null) {
				_psetId = new JTextField(12);
				_psetId.setText("1");

			}
			return _psetId;
		}

		public JTextField getBatchSize() {
			if (_BatchSize == null) {
				_BatchSize = new JTextField(12);
				_BatchSize.setText("10");

			}
			return _BatchSize;
		}
		
		public JTextField getBatchSizeNOK() {
			if (_BatchSizeNOK == null) {
				_BatchSizeNOK = new JTextField(12);
				_BatchSizeNOK.setText("10");

			}
			return _BatchSizeNOK;
		}

	}

	private InnerPanel _interactionPanel;

	public MID0019(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001", "002" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001", "002" });
		_MIDVerRevs.put(VERSIONS.FORD, new String[] { "001", "002" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null) {
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;
	}

	public void doCloseAction() {

	}

	public void doSendAction() {

		int rev = _interactionPanel.getSelectedCmdRev();
		String msg;
		if (rev == 2) { 
			String hdr = createHeader(27, 19, rev, 0);
			msg = hdr + String.format(
						"%03d%02d%02d",
						Integer.valueOf(_interactionPanel.getPsetId().getText()),
						Integer.valueOf(_interactionPanel.getBatchSize().getText()), 
						Integer.valueOf(_interactionPanel.getBatchSizeNOK().getText())).toString();
		}
		else {
			String hdr = createHeader(25, 19, rev, 0);
			msg = hdr + String.format(
					"%03d%02d",
					Integer.valueOf(_interactionPanel.getPsetId().getText()),
					Integer.valueOf(_interactionPanel.getBatchSize().getText())).toString();
		}
		ConnectionManager.getInstance().sendMessage(msg);

	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
	}

}
