package mids;

import java.util.Formatter;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0001.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;

@gui.menu.MenuGroup(name="JobData")
public class MID0030 extends AbstractMIDMenuItemAction {

	class InnerPanel extends AbstractSendPanel {

		private JPanel _mainPanel;

		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null) {
				_mainPanel = getBuilder().getPanel();
			}

			return _mainPanel;
		}

	}

	private InnerPanel _interactionPanel;

	public MID0030(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.FORD, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null) {
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;
	}

	public void doCloseAction() {


	}

	public void doSendAction() {
	String msg = createHeader(20, 30, _interactionPanel.getSelectedCmdRev(), 0);

	ConnectionManager.getInstance().sendMessage(msg);

	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
		
		if (opm.getMid() == 31) {
			String msg = extractHeader(opm);
			String jobs = extractVal(2, opm);		// number of jobs
			msg += "#jobs: " + jobs + "\n";
			int n = Integer.valueOf(jobs);
			for (int i = 0; i < n; i++) msg += "    " + extractVal(2, opm) + "\n";	// batch count of job
			Logger.getRootLogger().info(msg);
		}

	}

}
