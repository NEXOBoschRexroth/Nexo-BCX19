package mids;

import javax.swing.JPanel;

public class SwingJPanelTest extends JPanel {

	/**
	 * @param args
	 */
    public SwingJPanelTest() {
    }

}


