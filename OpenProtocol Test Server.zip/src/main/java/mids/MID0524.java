package mids;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0515.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;
import gui.menu.Statistics;

@gui.menu.MenuGroup(name="SocketTray")
public class MID0524 extends AbstractMIDMenuItemAction {

	
	private InnerPanel _interactionPanel;
	
	class InnerPanel extends AbstractSendPanel {

		private JTextField _lampen;

		private JPanel _mainPanel;

		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null) {
				_mainPanel = getBuilder().getPanel();

				getBuilder().add(new JLabel("Nussauswahl"), _cc.xy(1, 1));
				getBuilder().add(getLampen(), _cc.xy(2, 1));
			}

			return _mainPanel;
		}

		public JTextField getLampen() {
			if (_lampen == null) {
				_lampen = new JTextField(8);
				_lampen.setText("11111111");

			}
			return _lampen;
		}

	}

	
	public MID0524(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null) {
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;
	}

	public void doCloseAction() {
		// TODO Auto-generated method stub

	}

	public void doSendAction() {
		String msg = createHeader(44, 524, _interactionPanel.getSelectedCmdRev(), 0) + "01" + _interactionPanel.getLampen().getText().substring(0, 1)
		+ "02" + _interactionPanel.getLampen().getText().substring(1, 2)
		+ "03" + _interactionPanel.getLampen().getText().substring(2, 3)
		+ "04" + _interactionPanel.getLampen().getText().substring(3, 4)
		+ "05" + _interactionPanel.getLampen().getText().substring(4, 5)
		+ "06" + _interactionPanel.getLampen().getText().substring(5, 6)
		+ "07" + _interactionPanel.getLampen().getText().substring(6, 7)
		+ "08" + _interactionPanel.getLampen().getText().substring(7, 8);
		setTimeStamp();
		ConnectionManager.getInstance().sendMessage(msg);

	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
		if (Statistics.getInstance().getTimingCheckBox().isSelected()){
			String time = getTOF();
			if (opm.toString().indexOf("0524") == 0){
				Logger.getRootLogger().info("Timing: " + time);
			
			}
		}

	}

}
