package mids;

import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;
import gui.menu.Spindle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.prefs.Preferences;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import run.OpenProtocolInit;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import actions.AbstractSendPanel;

@gui.menu.MenuGroup(name="Connection")
public class MID0001 extends AbstractMIDMenuItemAction {

	class InnerPanel extends AbstractSendPanel{

		private JTextField _ipField;
		
		private JTextField _port;
		
		private JPanel _mainPanel;
		
//		private JComboBox _revision;

		private JComboBox _version;
		private VERSIONS _oldVersion;
		
		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action); // TODO hier 
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null){
				_mainPanel = getBuilder().getPanel();
				getBuilder().add(new JLabel("Controller IP"), _cc.xy(1,1));
				getBuilder().add(getIpField(),_cc.xy(2,1));
				getBuilder().add(new JLabel("Controller Port"), _cc.xy(1,2));
				getBuilder().add(getPort(),_cc.xy(2,2));
				getBuilder().add(new JLabel("Version"), _cc.xy(1, 3));
				getBuilder().add(getVersion(), _cc.xy (2,3));
				//getBuilder().add(new JLabel("Revision"), _cc.xy(1,4));
				//getBuilder().add(getRevision(),_cc.xy(2, 4));
			}
			
			return _mainPanel;
		}

		private String getPref(String key, String defVal)
		{
			Preferences prefs = Preferences.userNodeForPackage(OpenProtocolInit.class);
			try {
				return prefs.get(key, defVal);
			}
			catch (NumberFormatException e) {
				return defVal;
			}
		}
		private int getPref(String key, int defVal)
		{
			Preferences prefs = Preferences.userNodeForPackage(OpenProtocolInit.class);
			try {
				return Integer.parseInt(prefs.get(key, Integer.toString(defVal)));
			}
			catch (NumberFormatException e) {
				return defVal;
			}
		}
		
		
		public JTextField getIpField(){
			if (_ipField == null){
				_ipField = new JTextField(15);
				_ipField.setText(getPref("MID0001_IP", "10.23.232.180"));
				
			}
			return _ipField;
		}

		public JTextField getPort() {
			if (_port  ==null){
				_port = new JTextField(6);
				_port.setText(getPref("MID0001_Port", "4545"));
			}
			return _port;
		}
/*
		public JComboBox getRevision() {
			if (_revision == null){
				_revision = new JComboBox();
                for (String s: getMIDRevisions()) _revision.addItem(s);
			}
			return _revision;
		}
*/		
		private void selectVersion() {
            String ver = (String)_version.getSelectedItem();
    		if (ver == "Rexroth OP-BMW R1.0") ConnectionManager.getInstance().setVersion(VERSIONS.BMW);
    		else if (ver == "Rexroth OP-Ford R1.0") ConnectionManager.getInstance().setVersion(VERSIONS.FORD);
    		else ConnectionManager.getInstance().setVersion(VERSIONS.REXROTH);
    		_oldVersion = ConnectionManager.getInstance().getVersion();
    		getRevision().removeAllItems();
            for (String s: getMIDRevisions()) getRevision().addItem(s);
            getRevision().setVisible(true);
            // refresh menu items
            OpenProtocolInit.getInstance().getMainFrame().updateMids();
		}
		
		public JComboBox getVersion(){
			if (_version == null) {
				_version = new JComboBox();
				_version.addItem("Rexroth OP R1.0");
				_version.addItem("Rexroth OP-BMW R1.0");
				_version.addItem("Rexroth OP-Ford R1.0");
				try {
					_version.setSelectedIndex(getPref("MID0001_Rev", 0));
				}
				finally {}
				_version.addActionListener(new ActionListener() {
		            public void actionPerformed(ActionEvent ae) {
		            	//if (_oldVersion != ConnectionManager.getInstance().getVersion()) {
			            selectVersion();
		            	//}
		            }
		        });
            	selectVersion();
			}
			return _version;
		}
		
	}
	
	// special case: start is always enabled.
	public boolean getEnabled() {
		return true;
	}
/*
	public String[] getMIDRevisions() {
		return null;
		// default: return list of allowed revision codes based on the currently selected "VERSION"
		return _MIDVerRevs.get(ConnectionManager.getInstance().getVersion());
	}
*/	
	// special case: send disconnect and close all other frames...
	public void deactivate() {
		boolean active = isActive();
		super.deactivate();
		if (active) {
			OpenProtocolInit.getInstance().closeAllMids();
		}
	}
	
	private InnerPanel _interactionPanel;
	
	public MID0001(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		//this._MIDVerRevs.put(VERSIONS.NONE, new String[] { "" });
		this._MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001", "002", "003" });
		this._MIDVerRevs.put(VERSIONS.BMW, new String[] { "002" });
		this._MIDVerRevs.put(VERSIONS.FORD, new String[] { "001", "002" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null){
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;			
	}
	
	
	
	public void fireNewMessageEvent(OpenProtocolMessage opm) {
		if (opm.getMid() == 2 && opm.getRevision()==3){
			Logger.getRootLogger().info(extractHeader(opm)
			+ extractInfo(4, opm) + extractInfo(2, opm)  + extractInfo(25, opm) + extractInfo(3, opm)
			+ extractInfo(19, opm) + extractInfo(19, opm) + extractInfo(19, opm));
		}
		
/*	now implemented in MID0008 - which is a better place...		
		if (opm.getMid() == 6 ){
			ConnectionManager.getInstance().sendMessage(createHeader(20, 7, 1, 0));
		}
*/		
		
	}

	public void doCloseAction() {
		// TODO Auto-generated method stub
	}
	
	public void doSendAction() {
	
		if (!ConnectionManager.getInstance().isConnected()){
			try {
				ConnectionManager.getInstance().connect(InetAddress.getByName(_interactionPanel.getIpField().getText()),  Integer.valueOf(_interactionPanel.getPort().getText()));
			} catch (NumberFormatException e) {
				// TODO Auto-generated catch block
				Logger.getRootLogger().error(e);
				e.printStackTrace();
				return;
			} catch (UnknownHostException e) {
				// TODO Auto-generated catch block
				Logger.getRootLogger().error(e);
				e.printStackTrace();
				return;
			}
		}
		
		// successfully parsed - save as default
		Preferences prefs = Preferences.userNodeForPackage(OpenProtocolInit.class);
		prefs.put("MID0001_IP", _interactionPanel.getIpField().getText());
		prefs.put("MID0001_Port", _interactionPanel.getPort().getText());
		prefs.put("MID0001_Rev", Integer.toString(_interactionPanel.getVersion().getSelectedIndex()));

		if (!ConnectionManager.getInstance().isConnected()) {
			return;
		}
		String msg = createHeader(20, 1, Integer.valueOf(_interactionPanel.getRevision().getSelectedItem().toString()), 0);
		ConnectionManager.getInstance().sendMessage(msg);
	}

}
