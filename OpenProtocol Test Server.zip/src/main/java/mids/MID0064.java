package mids;

import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0001.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;

@gui.menu.MenuGroup(name="ResultData")
public class MID0064 extends AbstractMIDMenuItemAction {


	String[] data = new String[100];
	
	private int _pos = 0;
	
	class InnerPanel extends AbstractSendPanel{

		private JTextField _ipField;
		
		private JTextField _id;
		
		private JPanel _mainPanel;
		
		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action); // TODO hier 
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null){
				_mainPanel = getBuilder().getPanel();
				// FIXME hier l
				getBuilder().add(new JLabel("ID"), _cc.xy(1,1));
				getBuilder().add(getID(),_cc.xy(2,1));
				getBuilder().add(new JLabel("Revision"), _cc.xy(1,2));
				getBuilder().add(getRevision(),_cc.xy(2, 2));
			}
			
			return _mainPanel;
		}
		

		public JTextField getID() {
			if (_id  ==null){
				_id = new JTextField(10);
				_id.setText("0");
			}
			return _id;
		}

	}
	
	private InnerPanel _interactionPanel;
	
	public MID0064(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001", "002", "003", "004" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "004" });
		_MIDVerRevs.put(VERSIONS.FORD, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null){
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;			
	}
	
	
	
	protected String extractPureInfo(int length, OpenProtocolMessage msg){
		return extractInfo(length, msg).substring(3, length+3);
		
		
	}
	
	
	public void fireNewMessageEvent(OpenProtocolMessage opm) {
	
		if (opm.getMid() == 61) 
		{
			if (opm.getRevision() == 5) 
			{
				int i = 1;
				extractHeader(opm); 
				data[i++] = extractPureInfo (4, opm) ; 
				data[i++] = extractPureInfo (2, opm)  ; 
				data[i++] = extractPureInfo (25, opm) ; 
				data[i++] = extractPureInfo (25, opm); 
				data[i++] = extractPureInfo (4, opm);
				data[i++] = extractPureInfo (3, opm);
				data[i++] = extractPureInfo (2, opm);
				data[i++] = extractPureInfo (5, opm);
				data[i++] = extractPureInfo (4, opm);
				data[i++] = extractPureInfo (4, opm);
				data[i++] = extractPureInfo (1, opm);
				data[i++] = extractPureInfo (1, opm);
				data[i++] = extractPureInfo (1, opm);
				data[i++] = extractPureInfo (1, opm);
				data[i++] = extractPureInfo (1, opm);
				data[i++] = extractPureInfo (1, opm);
				data[i++] = extractPureInfo (1, opm);
				data[i++] = extractPureInfo (1, opm);
				data[i++] = extractPureInfo (1, opm);
				data[i++] = extractPureInfo (10, opm);
				data[i++] = extractPureInfo (6, opm);
				data[i++] = extractPureInfo (6, opm);
				data[i++] = extractPureInfo (6, opm);
				data[i++] = extractPureInfo (6, opm);
				data[i++] = extractPureInfo (5, opm);
				data[i++] = extractPureInfo (5, opm);
				data[i++] = extractPureInfo (5, opm);
				data[i++] = extractPureInfo (5, opm);
				data[i++] = extractPureInfo (5, opm);
				data[i++] = extractPureInfo (5, opm);
				data[i++] = extractPureInfo (5, opm);
				data[i++] = extractPureInfo (3, opm);
				data[i++] = extractPureInfo (3, opm);
				data[i++] = extractPureInfo (3, opm);
				data[i++] = extractPureInfo (6, opm);
				data[i++] = extractPureInfo (6, opm);
				data[i++] = extractPureInfo (6, opm);
				data[i++] = extractPureInfo (6, opm);
				data[i++] = extractPureInfo (6, opm);
				data[i++] = extractPureInfo (6, opm);
				data[i++] = extractPureInfo (10, opm);
				data[i++] = extractPureInfo (5, opm);
				data[i++] = extractPureInfo (5, opm);
				data[i++] = extractPureInfo (14, opm);
				data[i++] = extractPureInfo (19, opm);
				data[i++] = extractPureInfo (19, opm);
				data[i++] = extractPureInfo (25, opm);
				data[i++] = extractPureInfo (1, opm);
				data[i++] = extractPureInfo (2, opm);
				data[i++] = extractPureInfo (25, opm);
				data[i++] = extractPureInfo (25, opm);
				data[i++] = extractPureInfo (25, opm);
				data[i++] = extractPureInfo (4, opm);
			}
		} // getMid == 61
		else  if (opm.getMid() == 65)
		{ 
			if (opm.getRevision()==1 || (VERSIONS.BMW == ConnectionManager.getInstance().getVersion() && opm.getRevision()==4))
			{
				Logger.getRootLogger().info(extractHeader(opm)
						+ extractInfo(10, opm) + extractInfo(25, opm)  + extractInfo(3, opm) + extractInfo(4, opm)
						+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm) + extractInfo(6, opm)
						+ extractInfo(5, opm) + extractInfo(19, opm)  + extractInfo(1, opm));
				String data2[] = new String[12];
				extractHeader(opm);
				int i = 1;
				data2[i++] = extractPureInfo(10, opm);
				data2[i++] = extractPureInfo(25, opm);
				data2[i++] = extractPureInfo(3, opm);
				data2[i++] = extractPureInfo(4, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(6, opm);
				data2[i++] = extractPureInfo(5, opm);
				data2[i++] = extractPureInfo(19, opm);
				data2[i++] = extractPureInfo(1, opm);
				
				if ((data2[1].equals(data[41])) && (data2[2].equals(data[4])) && (data2[3].equals(data[6])) && (data2[4].equals(data[10])) &&
						(data2[5].equals(data[11])) && (data2[6].equals(data[13])) && (data2[7].equals(data[14])) && (data2[8].equals(data[24])) &&
						(data2[9].equals(data[28])) && (data2[10].equals(data[45])) && (data2[11].equals(data[12]))){
					Logger.getRootLogger().info("�bereinstimmung mit letzter Verschraubung");
				} else {
					Logger.getRootLogger().error("Old tightening stimmt nicht mit letzter Verschraubung �berein");
				}
			}
			else if (opm.getRevision()==2){
				Logger.getRootLogger().info(extractHeader(opm)
						+ extractInfo(10, opm) + extractInfo(25, opm)  + extractInfo(4, opm) + extractInfo(3, opm)
						+ extractInfo(2, opm) + extractInfo(5, opm)  + extractInfo(4, opm) + extractInfo(4, opm)
						+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm)
						+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm) + extractInfo(1, opm)
						+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(10, opm) + extractInfo(6, opm)
						+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(3, opm)
						+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(5, opm) + extractInfo(5, opm)
						+ extractInfo(14, opm) + extractInfo(19, opm));
			}
			else if (opm.getRevision()==3){
				Logger.getRootLogger().info(extractHeader(opm)
						+ extractInfo(10, opm) + extractInfo(25, opm)  + extractInfo(4, opm) + extractInfo(3, opm)
						+ extractInfo(2, opm) + extractInfo(5, opm)  + extractInfo(4, opm) + extractInfo(4, opm)
						+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm)
						+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm) + extractInfo(1, opm)
						+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(10, opm) + extractInfo(6, opm)
						+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(3, opm)
						+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(5, opm) + extractInfo(5, opm)
						+ extractInfo(14, opm) + extractInfo(19, opm)  + extractInfo(1, opm) + extractInfo(2, opm));
			}
			else if (opm.getRevision()==4){
				Logger.getRootLogger().info(extractHeader(opm)
						+ extractInfo(10, opm) + extractInfo(25, opm)  + extractInfo(4, opm) + extractInfo(3, opm)
						+ extractInfo(2, opm) + extractInfo(5, opm)  + extractInfo(4, opm) + extractInfo(4, opm)
						+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm)
						+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm) + extractInfo(1, opm)
						+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(10, opm) + extractInfo(6, opm)
						+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(3, opm)
						+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(5, opm) + extractInfo(5, opm)
						+ extractInfo(14, opm) + extractInfo(19, opm)  + extractInfo(1, opm) + extractInfo(2, opm)
						+ extractInfo(25, opm) + extractInfo(25, opm)  + extractInfo(25, opm));
				
				String data2[] = new String[40];
				extractHeader(opm);
				int i = 1;
				data2[i++] = extractPureInfo(10, opm);
				data2[i++] = extractPureInfo(25, opm);
				data2[i++] = extractPureInfo(4, opm);
				data2[i++] = extractPureInfo(3, opm);
				data2[i++] = extractPureInfo(2, opm);
				data2[i++] = extractPureInfo(5, opm);
				data2[i++] = extractPureInfo(4, opm);
				data2[i++] = extractPureInfo(4, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(10, opm);
				data2[i++] = extractPureInfo(6, opm);
				data2[i++] = extractPureInfo(5, opm);
				data2[i++] = extractPureInfo(5, opm);
				data2[i++] = extractPureInfo(3, opm);
				data2[i++] = extractPureInfo(6, opm);
				data2[i++] = extractPureInfo(6, opm);
				data2[i++] = extractPureInfo(5, opm);
				data2[i++] = extractPureInfo(5, opm);
				data2[i++] = extractPureInfo(14, opm);
				data2[i++] = extractPureInfo(19, opm);
				data2[i++] = extractPureInfo(1, opm);
				data2[i++] = extractPureInfo(2, opm);
				data2[i++] = extractPureInfo(25, opm);
				data2[i++] = extractPureInfo(25, opm);
				data2[i++] = extractPureInfo(25, opm);
				
				if ((data2[1].equals(data[41])) && (data2[2].equals(data[4])) && (data2[3].equals(data[5])) && (data2[4].equals(data[6])) &&
						(data2[5].equals(data[7])) && (data2[6].equals(data[8])) && (data2[7].equals(data[9])) && (data2[8].equals(data[10])) &&
						(data2[9].equals(data[11])) && (data2[10].equals(data[12])) && (data2[11].equals(data[13]))
						&& (data2[12].equals(data[14])) && (data2[13].equals(data[15])) && (data2[14].equals(data[16])) && (data2[15].equals(data[17])) &&
						(data2[16].equals(data[18])) && (data2[17].equals(data[19])) && (data2[18].equals(data[20])) && (data2[19].equals(data[24])) &&
						(data2[20].equals(data[28])) && (data2[21].equals(data[31])) && (data2[22].equals(data[34])) &&
						(data2[23].equals(data[37])) && (data2[24].equals(data[40])) && (data2[25].equals(data[42])) && (data2[26].equals(data[43])) &&
						(data2[27].equals(data[44])) && (data2[28].equals(data[45])) && (data2[29].equals(data[48])) && (data2[30].equals(data[49])) &&
						(data2[31].equals(data[50])) && (data2[32].equals(data[51])) && (data2[33].equals(data[52]))){
					Logger.getRootLogger().info("�bereinstimmung mit letzter Verschraubung");
				} else {
					Logger.getRootLogger().error("Old tightening stimmt nicht mit letzter Verschraubung �berein");
				}
			}
		} // mid == 0065
		
	}

	public void doCloseAction() {
		// TODO Auto-generated method stub
		
	}

	public void doSendAction() {
		String msg = createHeader(30, 64, _interactionPanel.getSelectedCmdRev(),  0) + String.format("%10d", Integer.valueOf(_interactionPanel.getID()
				.getText()));

		ConnectionManager.getInstance().sendMessage(msg);
		
	}

}

