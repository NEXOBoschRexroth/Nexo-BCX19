package mids;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.apache.log4j.Logger;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0040.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;

@gui.menu.MenuGroup(name="ResultData")
public class MID0063 extends AbstractMIDMenuItemAction {

	class InnerPanel extends AbstractSendPanel{
		
		private JPanel _mainPanel;
		
		
		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action); // TODO hier 
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null){
				_mainPanel = getBuilder().getPanel();
				// FIXME hier l

			}
			
			return _mainPanel;
		}
		
		
	}
	
	private InnerPanel _interactionPanel;
	
	public MID0063(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.FORD, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null){
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;			
	}
	
	
	
	public void fireNewMessageEvent(OpenProtocolMessage opm) {

	}

	public void doCloseAction() {
		// TODO Auto-generated method stub
		
	}

	public void doSendAction() {
		String msg = createHeader(20, 63, _interactionPanel.getSelectedCmdRev(), 0);
		
		ConnectionManager.getInstance().sendMessage(msg);
		
	}


}
