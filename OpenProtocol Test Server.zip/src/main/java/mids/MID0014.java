package mids;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0012.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;

@gui.menu.MenuGroup(name="ParameterSet")
public class MID0014 extends AbstractMIDMenuItemAction {

	class InnerPanel extends AbstractSendPanel {

		private JPanel _mainPanel;

		private JCheckBox _noAck;

		private JCheckBox _dontSendAck;

		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null) {
				_mainPanel = getBuilder().getPanel();
				getBuilder().add(getNoAck(), _cc.xy(2, 1));
				getBuilder().add(getDontSendAck(), _cc.xy(2, 2));
			}

			return _mainPanel;
		}



		public JCheckBox getNoAck() {
			if (_noAck == null) {
				_noAck = new JCheckBox("No Ack needed");
			}
			return _noAck;
		}

		public JCheckBox getDontSendAck() {
			if (_dontSendAck == null) {
				_dontSendAck = new JCheckBox("Don't Send Ack");
			}
			return _dontSendAck;
		}

	}
	private InnerPanel _interactionPanel;

	
	
	public MID0014(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.FORD, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null) {
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;
	}


	public void doCloseAction() {
		// TODO Auto-generated method stub

	}

	public void doSendAction() {
		String msg = createHeader(20, 14, 1, _interactionPanel.getNoAck().isSelected() ? 1 : 0);
		ConnectionManager.getInstance().sendMessage(msg);


	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
		if (opm.getMid() == 15 && !_interactionPanel.getDontSendAck().isSelected() && !_interactionPanel.getNoAck().isSelected()){
			String msg = createHeader(20, 16, _interactionPanel.getSelectedCmdRev(), 0);
			ConnectionManager.getInstance().sendMessage(msg);
		}

	}

}
