package mids;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0001.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;
import gui.menu.Statistics;

@gui.menu.MenuGroup(name="ResultData")
public class MID0100 extends AbstractMIDMenuItemAction {

	private InnerPanel _interactionPanel;

	class InnerPanel extends AbstractSendPanel {

		private JPanel _mainPanel;

		private JCheckBox _noAck;

		private JCheckBox _dontSendAck;

		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null) {
				_mainPanel = getBuilder().getPanel();

				getBuilder().add(getNoAck(), _cc.xy(2, 2));
				getBuilder().add(getDontSendAck(), _cc.xy(2, 3));

			}

			return _mainPanel;
		}

		public JCheckBox getNoAck() {
			if (_noAck == null) {
				_noAck = new JCheckBox("No Ack needed");
			}
			return _noAck;
		}

		public JCheckBox getDontSendAck() {
			if (_dontSendAck == null) {
				_dontSendAck = new JCheckBox("Don't Send Ack");
			}
			return _dontSendAck;
		}

	}

	public MID0100(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.FORD, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null) {
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;
	}

	public void doCloseAction() {
		// TODO Auto-generated method stub

	}

	public void doSendAction() {
		String msg = createHeader(20, 100, _interactionPanel.getSelectedCmdRev(),  _interactionPanel.getNoAck().isSelected() ? 1 : 0);
		
		ConnectionManager.getInstance().sendMessage(msg);

	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
		if (opm.getMid() == 101){
			Statistics.getInstance().incResults();
		}
		if (opm.getMid() == 101 && !_interactionPanel.getDontSendAck().isSelected() && !_interactionPanel.getNoAck().isSelected()){
			ConnectionManager.getInstance().sendMessage(createHeader(20, 102, 1, 0));
		}
		
		if (opm.getMid() == 101 && opm.getRevision() == 1){
			String msg = extractHeader(opm)
			+ extractInfo(2, opm) + extractInfo(25, opm)  + extractInfo(2, opm) + extractInfo(3, opm)
			+ extractInfo(4, opm) + extractInfo(4, opm)  + extractInfo(1, opm) + extractInfo(6, opm)
			+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(5, opm) + extractInfo(5, opm)
			+ extractInfo(5, opm) + extractInfo(19, opm)  + extractInfo(19, opm) + extractInfo(5, opm)
			+ extractInfo(1, opm);
			int Spindles = Integer.valueOf(opm.toString().substring(0, 2));
			msg += extractVal(2, opm) + ":\n";
			for (int i = 0; i < Spindles; i++) {
				msg += "    " + extractVal(2, opm) + ": " + extractVal(2, opm) + " " + extractVal(1, opm) + " " + extractVal(1, opm)
						+ " " + extractVal(6, opm) + " " + extractVal(1, opm) + " " + extractVal(5, opm) + "\n";
			}
			Logger.getRootLogger().info(msg);
		}

	}

}
