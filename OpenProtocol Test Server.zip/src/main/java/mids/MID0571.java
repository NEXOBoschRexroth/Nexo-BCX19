package mids;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0012.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;

@gui.menu.MenuGroup(name="Job")
public class MID0571 extends AbstractMIDMenuItemAction {

	class InnerPanel extends AbstractSendPanel {

		private JPanel _mainPanel;

		private JCheckBox value;

		private JCheckBox _dontSendAck;

		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null) {
				_mainPanel = getBuilder().getPanel();
				getBuilder().add(getValue(), _cc.xy(2, 1));
			}

			return _mainPanel;
		}



		public JCheckBox getValue() {
			if (value == null) {
				value = new JCheckBox("Value");
			}
			return value;
		}

	}
	private InnerPanel _interactionPanel;

	
	
	public MID0571(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null) {
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;
	}


	public void doCloseAction() {
		// TODO Auto-generated method stub

	}

	public void doSendAction() {
		String msg = createHeader(23, 571, _interactionPanel.getSelectedCmdRev(), 0) + "01" + (_interactionPanel.getValue().isSelected() ?  "1" : "0");
		ConnectionManager.getInstance().sendMessage(msg);


	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
	}

}
