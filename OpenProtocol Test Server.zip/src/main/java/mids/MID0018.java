package mids;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0012.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;
import gui.menu.Statistics;

@gui.menu.MenuGroup(name="ParameterSet")
public class MID0018 extends AbstractMIDMenuItemAction {

	class InnerPanel extends AbstractSendPanel {

		private JTextField _psetId;

		private JPanel _mainPanel;

		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null) {
				_mainPanel = getBuilder().getPanel();

				getBuilder().add(new JLabel("Programm ID"), _cc.xy(1, 1));
				getBuilder().add(getPsetId(), _cc.xy(2, 1));
			}

			return _mainPanel;
		}

		public JTextField getPsetId() {
			if (_psetId == null) {
				_psetId = new JTextField(12);
				_psetId.setText("1");

			}
			return _psetId;
		}

	}

	private InnerPanel _interactionPanel;

	public MID0018(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.FORD, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null) {
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;
	}

	public void doCloseAction() {

	}

	public void doSendAction() {

		String msg = createHeader(23, 18, _interactionPanel.getSelectedCmdRev(), 0)
				+ String.format(
						"%03d",
						Integer
								.valueOf(_interactionPanel.getPsetId()
										.getText())).toString();
		setTimeStamp();
		ConnectionManager.getInstance().sendMessage(msg);

	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
		if (Statistics.getInstance().getTimingCheckBox().isSelected()){
			String time = getTOF();
			if (opm.toString().indexOf("0018") == 0){
				Logger.getRootLogger().info("Timing: " + time);
			
			}
		}

	}

}
