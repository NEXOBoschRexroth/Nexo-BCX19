package mids;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0018.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;
import gui.menu.Statistics;

@gui.menu.MenuGroup(name="HVO")
public class MID0515 extends AbstractMIDMenuItemAction {

	
	class InnerPanel extends AbstractSendPanel {

		private JTextField _lampen;
		private JTextField _2light;
		private JTextField _2state;

		private JPanel _mainPanel;

		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);

		}
		protected void onRevisionChanged() {
            int rev = getSelectedCmdRev();
            getLampen().setVisible(rev == 1);
   			get2Light().setVisible(rev == 2);
   			get2State().setVisible(rev == 2);
		}
		

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null) {
				_mainPanel = getBuilder().getPanel();

				getBuilder().add(new JLabel("Lampenbefehl"), _cc.xy(1, 1));
				getBuilder().add(getLampen(), _cc.xy(2, 1));
				getBuilder().add(new JLabel("Lampen"), _cc.xy(1, 2));
				getBuilder().add(get2Light(), _cc.xy(2, 2));
				getBuilder().add(new JLabel("Wert"), _cc.xy(1, 3));
				getBuilder().add(get2State(), _cc.xy(2, 3));
			}

			return _mainPanel;
		}

		public JTextField getLampen() {
			if (_lampen == null) {
				_lampen = new JTextField(4);
				_lampen.setText("1111");

			}
			return _lampen;
		}
		public JTextField get2Light() {
			if (_2light == null) {
				_2light = new JTextField(3);
				_2light.setText("1");

			}
			return _2light;
		}
		public JTextField get2State() {
			if (_2state == null) {
				_2state = new JTextField(3);
				_2state.setText("1");

			}
			return _2state;
		}
		
		public int getLightNr() {
			return Integer.parseInt(get2Light().getText());
		}
		public int getStatus() {
			return Integer.parseInt(get2State().getText());
		}

	}

	private InnerPanel _interactionPanel;

	public MID0515(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001", "002" });
	}
	
	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null) {
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;
	}
	

	public void doCloseAction() {
		// TODO Auto-generated method stub

	}

	public void doSendAction() {
		String msg; 
		if (1 == _interactionPanel.getSelectedCmdRev())
		{
			msg = createHeader(32, 515, _interactionPanel.getSelectedCmdRev(), 0) 
			+ "01" + _interactionPanel.getLampen().getText().substring(0, 1)
			+ "02" + _interactionPanel.getLampen().getText().substring(1, 2)
			+ "03" + _interactionPanel.getLampen().getText().substring(2, 3)
			+ "04" + _interactionPanel.getLampen().getText().substring(3, 4);
			setTimeStamp();
		}
		else {
			msg = createHeader(32, 515, _interactionPanel.getSelectedCmdRev(), 0) 
			+ "01" + String.format("%03d", _interactionPanel.getLightNr())
			+ "02" + String.format("%03d", _interactionPanel.getStatus());
			setTimeStamp();
		}
		ConnectionManager.getInstance().sendMessage(msg);

	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
		if (Statistics.getInstance().getTimingCheckBox().isSelected()){
			String time = getTOF();
			if (opm.toString().indexOf("0515") == 0){
				Logger.getRootLogger().info("Timing: " + time);
			
			}
		}

	}

}
