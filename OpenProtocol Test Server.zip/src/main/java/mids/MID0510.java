package mids;

import javax.swing.JComponent;
import javax.swing.JPanel;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0500.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;

@gui.menu.MenuGroup(name="HVO")
public class MID0510 extends AbstractMIDMenuItemAction {

	private InnerPanel _innerPanel;
	private AbstractSendPanel _interactionPanel;
	
	class InnerPanel extends AbstractSendPanel{

		private JPanel _mainPanel;
		
		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null){
				_mainPanel = getBuilder().getPanel();
				
			}
			
			return _mainPanel;
		}
	
	}
	
	public MID0510(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null){
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;	
	}

	public void doCloseAction() {

	}

	public void doSendAction() {
		String msg = createHeader(20, 510, _interactionPanel.getSelectedCmdRev(), 0);
		ConnectionManager.getInstance().sendMessage(msg);

	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
		if (opm.getMid() == 511){
			ConnectionManager.getInstance().sendMessage(createHeader(20, 512, 1, 0));
		}
	}

}
