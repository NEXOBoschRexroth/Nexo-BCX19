package mids;

import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import manager.ConnectionManager;
import message.OpenProtocolMessage;

import org.apache.log4j.Logger;

import actions.AbstractSendPanel;

@gui.menu.MenuGroup(name="ToolData")
public class MID0040 extends AbstractMIDMenuItemAction {



	class InnerPanel extends AbstractSendPanel{
	
		private JPanel _mainPanel;
		
		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action); // TODO hier 
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null){
				_mainPanel = getBuilder().getPanel();
				// FIXME hier l
				getBuilder().add(new JLabel("Revision"), _cc.xy(1,1));
				getBuilder().add(getRevision(),_cc.xy(2, 1));
			}
			
			return _mainPanel;
		}
		
	}
		
	
	
	private InnerPanel _interactionPanel;
	
	public MID0040(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001", "002" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.FORD, new String[] { "001", "002" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null){
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;			
	}
	
	
	
	public void fireNewMessageEvent(OpenProtocolMessage opm) {
		if (opm.getMid() == 41 && opm.getRevision()==1){
			Logger.getRootLogger().info(extractHeader(opm)
			+ extractInfo(14, opm) + extractInfo(10, opm)  + extractInfo(19, opm) + extractInfo(10, opm));
		}
		if (opm.getMid() == 41 && opm.getRevision()==2){
			//Tool serial number 				01		14
			//Total number of tightening		02		10
			//Last calibration date				03		19
			//Controller Serial Number			04		10
			//Firmware Version 1				05		19
			//Firmware Version 2				06		19
			//Future							07		20
			Logger.getRootLogger().info(extractHeader(opm)
					+ extractInfo(14, opm) + extractInfo(10, opm)  + extractInfo(19, opm) + extractInfo(10, opm)
					+ extractInfo(19, opm) + extractInfo(19, opm)  + extractInfo(20, opm));
		}
		
	}

	public void doCloseAction() {
		// TODO Auto-generated method stub
		
	}

	public void doSendAction() {

		String msg = createHeader(20, 40, _interactionPanel.getSelectedCmdRev(), 0);
			
		ConnectionManager.getInstance().sendMessage(msg);
		
	}


}
