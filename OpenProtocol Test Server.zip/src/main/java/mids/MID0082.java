package mids;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0012.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;

@gui.menu.MenuGroup(name="Time")
public class MID0082 extends AbstractMIDMenuItemAction {

	class InnerPanel extends AbstractSendPanel {

		private JTextField _dateTime;

		private JPanel _mainPanel;
		
		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null) {
				_mainPanel = getBuilder().getPanel();

				getBuilder().add(new JLabel("Date/Time"), _cc.xy(1, 1));
				getBuilder().add(getDateTime(), _cc.xy(2, 1));
			}

			return _mainPanel;
		}

		public JTextField getDateTime() {
			if (_dateTime == null) {
				_dateTime = new JTextField(30);
				DateFormat sdf = SimpleDateFormat.getDateTimeInstance();
				Date date = new Date();
				_dateTime.setText(sdf.format(date));

			}
			return _dateTime;
		}
		public Date getSelectedDateTime() {
			DateFormat sdf = SimpleDateFormat.getDateTimeInstance();
			try {
				Date date = sdf.parse(getDateTime().getText());
				return date;
			} catch (ParseException e) {
				return new Date();
			}
		}

	}

	private InnerPanel _interactionPanel;

	public MID0082(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "001" });
		_MIDVerRevs.put(VERSIONS.FORD, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null) {
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;
	}

	public void doCloseAction() {

	}

	public void doSendAction() 
	{
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd:HH:mm:ss");
		Date d = _interactionPanel.getSelectedDateTime();
		String sDate = sdf.format(d);
		
		String hdr = createHeader(39, 82,  _interactionPanel.getSelectedCmdRev(), 0);
		String msg = hdr + sDate;
		ConnectionManager.getInstance().sendMessage(msg);
	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
	}

}
