package mids;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import org.apache.log4j.Logger;

import manager.ConnectionManager;
import message.OpenProtocolMessage;
import mids.MID0001.InnerPanel;
import actions.AbstractSendPanel;
import gui.helper.VERSIONS;
import gui.menu.AbstractMIDMenuItemAction;
import gui.menu.IMIDMenuItemAction;
import gui.menu.Statistics;

@gui.menu.MenuGroup(name="ResultData")
public class MID0060 extends AbstractMIDMenuItemAction {

	private InnerPanel _interactionPanel;

	class InnerPanel extends AbstractSendPanel {

		private JPanel _mainPanel;

		private JCheckBox _noAck;

		private JCheckBox _dontSendAck;

		public InnerPanel(IMIDMenuItemAction _action) {
			super(_action);
		}

		@Override
		protected JPanel getInteractionPanel() {
			if (_mainPanel == null) {
				_mainPanel = getBuilder().getPanel();

				getBuilder().add(getNoAck(), _cc.xy(2, 2));
				getBuilder().add(getDontSendAck(), _cc.xy(2, 3));

			}

			return _mainPanel;
		}

		public JCheckBox getNoAck() {
			if (_noAck == null) {
				_noAck = new JCheckBox("No Ack needed");
			}
			return _noAck;
		}

		public JCheckBox getDontSendAck() {
			if (_dontSendAck == null) {
				_dontSendAck = new JCheckBox("Don't Send Ack");
			}
			return _dontSendAck;
		}

	}

	public MID0060(JComponent parent, String name) {
		super(parent, name);
		// Add supported revisions
		_MIDVerRevs.put(VERSIONS.REXROTH, new String[] { "001", "002", "003", "004", "005", "999" });
		_MIDVerRevs.put(VERSIONS.BMW, new String[] { "004" });
		_MIDVerRevs.put(VERSIONS.FORD, new String[] { "001" });
	}

	@Override
	public AbstractSendPanel getDisplayedComponent() {
		if (_interactionPanel == null) {
			_interactionPanel = new InnerPanel(this);
		}
		return _interactionPanel;
	}

	public void doCloseAction() {
		// TODO Auto-generated method stub

	}

	public void doSendAction() {
		String msg = createHeader(20, 60, _interactionPanel.getSelectedCmdRev(),  _interactionPanel.getNoAck().isSelected() ? 1 : 0);
		
		ConnectionManager.getInstance().sendMessage(msg);

	}

	public void fireNewMessageEvent(OpenProtocolMessage opm) {
		if (opm.getMid() == 61){
			Statistics.getInstance().incResults();
		}
		if (opm.getMid() == 61 && !_interactionPanel.getDontSendAck().isSelected() && !_interactionPanel.getNoAck().isSelected()){
			ConnectionManager.getInstance().sendMessage(createHeader(20, 62, 1, 0));
		}
		
		if (opm.getMid() == 61 && opm.getRevision() == 1){
			Logger.getRootLogger().info(extractHeader(opm)
			+ extractInfo(4, opm) + extractInfo(2, opm)  + extractInfo(25, opm) + extractInfo(25, opm)
			+ extractInfo(2, opm) + extractInfo(3, opm)  + extractInfo(4, opm) + extractInfo(4, opm)
			+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm) + extractInfo(6, opm)
			+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(5, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(5, opm) + extractInfo(19, opm)
			+ extractInfo(19, opm) + extractInfo(1, opm)  + extractInfo(10, opm));
		}
		
		if (opm.getMid() == 61 && opm.getRevision() == 2){
			Logger.getRootLogger().info(extractHeader(opm)
			+ extractInfo(4, opm) + extractInfo(2, opm)  + extractInfo(25, opm) + extractInfo(25, opm)
			+ extractInfo(4, opm) + extractInfo(3, opm)  + extractInfo(2, opm) + extractInfo(5, opm)
			+ extractInfo(4, opm) + extractInfo(4, opm)  + extractInfo(1, opm) + extractInfo(1, opm)
			+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm) + extractInfo(1, opm)
			+ extractInfo(1, opm) + extractInfo(1, opm) + extractInfo(1, opm) + extractInfo(10, opm) + extractInfo(6, opm)
			+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(5, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(5, opm) + extractInfo(5, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(3, opm) + extractInfo(3, opm)
			+ extractInfo(3, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(6, opm)
			+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(10, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(14, opm) + extractInfo(19, opm)
			+ extractInfo(19, opm));	
		}
		
		if (opm.getMid() == 61 && opm.getRevision() == 3){
			Logger.getRootLogger().info(extractHeader(opm)
			+ extractInfo(4, opm) + extractInfo(2, opm)  + extractInfo(25, opm) + extractInfo(25, opm)
			+ extractInfo(4, opm) + extractInfo(3, opm)  + extractInfo(2, opm) + extractInfo(5, opm)
			+ extractInfo(4, opm) + extractInfo(4, opm)  + extractInfo(1, opm) + extractInfo(1, opm)
			+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm) + extractInfo(1, opm)
			+ extractInfo(1, opm) + extractInfo(1, opm) + extractInfo(1, opm) + extractInfo(10, opm) + extractInfo(6, opm)
			+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(5, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(5, opm) + extractInfo(5, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(3, opm) + extractInfo(3, opm)
			+ extractInfo(3, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(6, opm)
			+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(10, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(14, opm) + extractInfo(19, opm)
			+ extractInfo(19, opm) + extractInfo(25, opm) + extractInfo(1, opm) + extractInfo(2, opm));	
		}
		if (opm.getMid() == 61 && opm.getRevision() == 4){
			Logger.getRootLogger().info(extractHeader(opm)
			+ extractInfo(4, opm) + extractInfo(2, opm)  + extractInfo(25, opm) + extractInfo(25, opm)
			+ extractInfo(4, opm) + extractInfo(3, opm)  + extractInfo(2, opm) + extractInfo(5, opm)
			+ extractInfo(4, opm) + extractInfo(4, opm)  + extractInfo(1, opm) + extractInfo(1, opm)
			+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm) + extractInfo(1, opm)
			+ extractInfo(1, opm) + extractInfo(1, opm) + extractInfo(1, opm) + extractInfo(10, opm) + extractInfo(6, opm)
			+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(5, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(5, opm) + extractInfo(5, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(3, opm) + extractInfo(3, opm)
			+ extractInfo(3, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(6, opm)
			+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(10, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(14, opm) + extractInfo(19, opm)
			+ extractInfo(19, opm) + extractInfo(25, opm) + extractInfo(1, opm) + extractInfo(2, opm)
			+ extractInfo(25, opm) + extractInfo(25, opm) + extractInfo(25, opm));	
		}
		if (opm.getMid() == 61 && opm.getRevision() == 5){
			String output = extractHeader(opm)
			+ extractInfo(4, opm) + extractInfo(2, opm)  + extractInfo(25, opm) + extractInfo(25, opm)
			+ extractInfo(4, opm) + extractInfo(3, opm)  + extractInfo(2, opm) + extractInfo(5, opm)
			+ extractInfo(4, opm) + extractInfo(4, opm)  + extractInfo(1, opm) + extractInfo(1, opm)
			+ extractInfo(1, opm) + extractInfo(1, opm)  + extractInfo(1, opm) + extractInfo(1, opm)
			+ extractInfo(1, opm) + extractInfo(1, opm) + extractInfo(1, opm) + extractInfo(10, opm) + extractInfo(6, opm)
			+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(5, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(5, opm) + extractInfo(5, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(3, opm) + extractInfo(3, opm)
			+ extractInfo(3, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(6, opm)
			+ extractInfo(6, opm) + extractInfo(6, opm)  + extractInfo(6, opm) + extractInfo(10, opm)
			+ extractInfo(5, opm) + extractInfo(5, opm)  + extractInfo(14, opm) + extractInfo(19, opm)
			+ extractInfo(19, opm) + extractInfo(25, opm) + extractInfo(1, opm) + extractInfo(2, opm)
			+ extractInfo(25, opm) + extractInfo(25, opm) + extractInfo(25, opm)  + extractInfo(4, opm);
			Logger.getRootLogger().info(output);
			if (Statistics.getInstance().getSaveResCheckBox().isSelected()){
				File f = new File(Statistics.getInstance().getDirectoryField().getText());
				
				
				if (f.exists() && f.isDirectory()){
					int prg = output.indexOf("06\t") +4;
					File dir = new File(f.getPath() + "\\" + "PRG_"+output.substring(prg, prg+2));
					if (!dir.exists()){
						dir.mkdir();
					}
					
					
					int i1 = output.indexOf("04\t") +3;

					String id = "OP" + output.substring(i1+2, i1+25)+ ".txt";
					File reFile  = new File(dir.getPath() +"\\"+ id);
					if (!reFile.exists()){
						try {
							
							reFile.createNewFile();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
					try {
						FileWriter fw = new FileWriter(reFile);
						fw.write(output);
						fw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
		
		if (opm.getMid() == 61 && opm.getRevision() == 999){
			Logger.getRootLogger().info(extractHeader(opm) + opm.toString().substring(0,25) + "\n" 
					+ opm.toString().substring(25,27) + "\n"+ opm.toString().substring(27,30) + "\n"
					+ opm.toString().substring(30,34) + "\n"+ opm.toString().substring(34,38) + "\n"
					+ opm.toString().substring(38,39) + "\n"+ opm.toString().substring(39,40) + "\n"
					+ opm.toString().substring(40,41) + "\n"+ opm.toString().substring(41,42) + "\n"
					+ opm.toString().substring(42,48) + "\n"+ opm.toString().substring(48,53) + "\n"
					+ opm.toString().substring(53,72) + "\n"+ opm.toString().substring(72,91) + "\n"
					+ opm.toString().substring(91,101) + "\n");
		}
	}

}
