package actions;

import gui.menu.IMIDMenuItemAction;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

import run.OpenProtocolInit;

import com.jgoodies.forms.builder.DefaultFormBuilder;
import com.jgoodies.forms.layout.CellConstraints;
import com.jgoodies.forms.layout.FormLayout;

public abstract class AbstractSendPanel extends JPanel {

	private JPanel _headerPanel;

	private JPanel _buttonsPanel;

	private IMIDMenuItemAction _midAction;

	private JButton _sendButton;

	private FormLayout _layout;

	private DefaultFormBuilder _builder;

	protected CellConstraints _cc = new CellConstraints();

	protected JComboBox _cmdRev;
	
	public AbstractSendPanel(IMIDMenuItemAction _action) {
		_midAction = _action;
		FormLayout layout = new FormLayout("default", "30px, default, 30px");
		DefaultFormBuilder builder = new DefaultFormBuilder(layout, this);

		CellConstraints cc = new CellConstraints();
		builder.add(getHeaderPanel(), cc.xy(1, 1));
		//builder.addLabel(_midAction.getClass().getSimpleName() + " " + _midAction.getName(), cc.xy(1, 1));
		builder.add(getInteractionPanel(), cc.xy(1, 2));
		builder.add(getButtonsPanel(), cc.xy(1, 3));
	}

	private JPanel getButtonsPanel() {
		if (_buttonsPanel == null) {
			_buttonsPanel = new JPanel();
//			if (getMidAction().getMIDRevisions() != null) {
				// we show the generic MID revions here
				_buttonsPanel.add(new JLabel("Revision")); //, _cc.xy(1,4));
				_buttonsPanel.add(getRevision());//,_cc.xy(2, 4));
//			}
			_buttonsPanel.add(getSendButton());
		}
		return _buttonsPanel;
	}
	
	private JPanel getHeaderPanel() {
		if (_headerPanel == null) {
			_headerPanel = new JPanel();
			_headerPanel.add(new JLabel(_midAction.getClass().getSimpleName() + " " + _midAction.getName())); 
		}
		return _headerPanel;
	}

	protected abstract JPanel getInteractionPanel();

	private IMIDMenuItemAction getMidAction() {
		return _midAction;
	}

	public JButton getSendButton() {
		if (_sendButton == null) {
			_sendButton = new JButton(new AbstractAction("Send") {

				public void actionPerformed(ActionEvent arg0) {
					getMidAction().doSendAction();

				}
			});
		}
		return _sendButton;
	}
	
	private String[] getListOfRevisions() {
		String revs[];
		if (OpenProtocolInit.getInstance().getMainFrame().getShowAllRevsChecked()) {
			// all possible revisions
			revs = getMidAction().getAllMIDRevisions();
		}
		else {
			// revisions specific to currently selected protocol version
			revs = getMidAction().getMIDRevisions();
		}
		return revs;
	}
	private void refreshRevisionComboItems() {
		if (_cmdRev == null) {
			return;
		}
		_cmdRev.removeAllItems();
		String revs[] = getListOfRevisions();
        if (revs != null) {
        	for (String s: revs) _cmdRev.addItem(s);
        }
	}

	public JComboBox getRevision() {
		if (_cmdRev == null) {
			_cmdRev = new JComboBox();
			refreshRevisionComboItems();
			_cmdRev.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent ae) {
	            	if (_cmdRev.getItemCount() > 0) {
	            		onRevisionChanged();
	            	}
	            }
	        });
		}
		return _cmdRev;
	}
	
	public void onVersionChanged()
	{
		// Version has changed externally - refresh GUI.
		refreshRevisionComboItems();
    	onRevisionChanged();
	}
	
	public void onShow() {
		// Frame is activated - initialize current list of revisions
		refreshRevisionComboItems();
    	onRevisionChanged();
	}

	protected void onRevisionChanged() {
		// do nothing here - any derived class may hook this event
	}
	
	public int getSelectedCmdRev() {
		//if (getMidAction().getMIDRevisions() != null) {
		if (getRevision().getSelectedIndex() >= 0) {
			return Integer.valueOf(getRevision().getSelectedItem().toString());
		}
		return -1;
	}
	
	public FormLayout getFormLayout() {
		if (_layout == null) {
			_layout = new FormLayout("max(default;50px), max(default;100px)",
					"default,default,default,default,default,default");
		}
		return _layout;
	}

	public DefaultFormBuilder getBuilder() {
		if (_builder == null) {
			_builder = new DefaultFormBuilder(getFormLayout());
		}
		return _builder;
	}

}
